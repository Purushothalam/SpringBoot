package com.elab;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ElabStarter {
	public static void main(String[] args){
		SpringApplication.run(ElabStarter.class, args);
	}

}
