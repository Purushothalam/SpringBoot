package com.elab.controller;

import java.io.FileNotFoundException;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.elab.exception.HeloclinicException;
import com.elab.model.AdminLoginBO;
import com.elab.model.ChangePassword;
import com.elab.service.AdminService;
import com.elab.service.AdminServiceImpl;
import com.elab.utils.CookiesGenerator;
import com.elab.utils.EncryptAndDecrypt;
import com.elab.utils.HelloClinicResourceBundle;
import com.elab.utils.PaginationClass;

@RestController
@RequestMapping("/api")
@CrossOrigin("http://localhost:4200")
@Scope("session")
public class AdminController {
	String salt = "this is a simple clear salt";
	@Autowired
	AdminService adminService;
	@PostMapping("/adminsignin")
	public AdminLoginBO adminAthentication(@RequestBody AdminLoginBO adminLoginBO ,HttpServletRequest request, HttpServletResponse response,HttpSession session){
		try {

			if (null != session.getAttribute("id") && null != session.getAttribute("patient")
					|| null != session.getAttribute("doctor") || null != session.getAttribute("lablogin")
					|| null != session.getAttribute("Donor")) {

				//model.addAttribute("warningMessage", HelloClinicResourceBundle.getValue("Logout.user"));
				//return "redirect:/admin-sign-in";
			}

			boolean rememberMe = adminLoginBO.getRememberMe();
			// This set of part is used to add the user email and
			// password
			// to cookies.
			Map<String, String> cookiesObject = new HashMap<String, String>();
			cookiesObject.put("email", adminLoginBO.getEmailAddress());
			cookiesObject.put("password", adminLoginBO.getPassword());
			CookiesGenerator cookiesGenerator = new CookiesGenerator();
			cookiesGenerator.addCookies(request, response, cookiesObject, "admin", rememberMe);


			//AdminServiceImpl ser=new AdminServiceImpl();
			AdminLoginBO adminLogin=adminService.authenticate(adminLoginBO);

			long s=1;
			if (null!=adminLogin&&null!=adminLogin.getEmailAddress()) {
				session.setAttribute("ids",s);
				session.setAttribute("adminId", adminLoginBO.getId());
				session.setAttribute("emailId", adminLoginBO.getEmailAddress());
				session.setAttribute("userType", adminLoginBO.getUserType());

				if (null != session.getAttribute("id")) {
					session.setAttribute("admin", "admin");
					session.setAttribute("login", "login");

				}

				return adminLogin;
			} else {
				return null;
			}
		} catch (Exception jb) {

		}

		return null;


	}

	@GetMapping("/view-admin-profile/{id}")

	public AdminLoginBO retrieveAdminProfile(@PathVariable String id, Model model, HttpServletRequest request,HttpSession session) {

		String value = CheckSeesion(request);
		if (value != null) {
			//return value;
		}
		//HttpSession session = request.getSession();
		AdminLoginBO loginBO = new AdminLoginBO();

		if (null != request.getParameter("message")) {
			String message = request.getParameter("message");
			model.addAttribute("message", message);
		}
		try {
			//session.setAttribute("ids", 2);
			//if(null!=session.getAttribute("ids")){

			//long loginId = (Long) session.getAttribute("ids");
			//long loginId=1;
			loginBO.setId(Long.parseLong(id));
			AdminLoginBO adminLoginBO = adminService.retrieveProfile(loginBO);
			//List<AdminLoginBO> profileList = adminLoginBO.getAllProfileList();

			return adminLoginBO;
			//}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;


	}
	@PostMapping("/add-admin-user/{id}")
	public boolean addAdminUser(@PathVariable String id ,@RequestBody AdminLoginBO loginBO,
			Model model, HttpServletRequest request){

		//model.addAttribute("type", "add");
		//retrieveAdminUser(model, request);
		
		//HttpSession session = request.getSession();
		//long id = (Long) session.getAttribute("id");
		try {


			/*if (adminService.findAdminUser(loginBO.getEmailAddress())) {

				model.addAttribute("InfoMessage", HelloClinicResourceBundle.getValue("Validate.AdminUser"));

				model.addAttribute("page_title",
						messageSource.getMessage("admin.create.profile", null, request.getLocale()));
				return "add-admin-user";
			}*/
			long adminId=Long.parseLong(id);
			loginBO.setCreatedBy(adminId);
			loginBO.setModifiedBy(adminId);
			loginBO.setIsDeleted(true);
			String passwordEnc = EncryptAndDecrypt.encrypt(loginBO.getPassword(), salt);
			loginBO.setPassword(passwordEnc);
			boolean isStatus = adminService.addAdminUser(loginBO);
			if (isStatus) {
				/*model.addAttribute("message", "Admin User" + " " + loginBO.getEmailAddress() + " "
						+ HelloClinicResourceBundle.getValue("Validate.Success"));*/
				return true;
			} else {

				/*model.addAttribute("errormessage",
						"User " + loginBO.getEmailAddress() + HelloClinicResourceBundle.getValue("Validate.Failure"));
				model.addAttribute("page_title",
						messageSource.getMessage("admin.create.profile", null, request.getLocale()));*/
				return false;
			}

		} catch (Exception e) {

		}
		return false;

		//return "add-admin-user";
	}
	@PostMapping("/admin-change-password-after-login/{emailId}")
	public boolean changePassword(@PathVariable String emailId,@RequestBody ChangePassword changePassword,HttpServletRequest request){

		try {

			/*if (!changePassword.getPassword().equals(changePassword.getConfirmPassword())) {
				result.rejectValue("confirmPassword", "Validate.Password");
				// model.addAttribute("message", "PassWord should be equal.");
				model.addAttribute("page_title",
						messageSource.getMessage("admin.change.password", null, request.getLocale()));
				return "admin-change-password";
			}
			if (result.hasErrors()) {
				model.addAttribute("page_title",
						messageSource.getMessage("admin.change.password", null, request.getLocale()));
				return "admin-change-password";
			}
*/
			AdminLoginBO loginBO = new AdminLoginBO();

			if(null!=emailId){
				loginBO.setEmailAddress(emailId+".com");
			}
			String passwordEnc = EncryptAndDecrypt.encrypt(changePassword.getPassword(), salt);
			loginBO.setPassword(passwordEnc);
			boolean status = adminService.changePassword(loginBO);

			if (status) {

				//model.addAttribute("message", HelloClinicResourceBundle.getValue("Password.Change.Success"));
				//model.addAttribute("signIn", changePassword);
				return true;

			} else {
				/*model.addAttribute("errormessage", HelloClinicResourceBundle.getValue("Validate.User.Exit"));
				model.addAttribute("page_title",
						messageSource.getMessage("admin.change.password", null, request.getLocale()));*/
				return false;
			}

		} catch (Exception e) {

		}
		return false;

		//return "admin-change-password";
	}
	@GetMapping("/view-admin-users")
	public List<AdminLoginBO> getAllUser(){
		return retrieveAdminUser();
		
	}
	private List<AdminLoginBO> retrieveAdminUser() {
		int page = 1;
	//	String paging = request.getParameter("page");
		AdminLoginBO loginBO = new AdminLoginBO();
		try {
			/*if (null != paging) {
				page = Integer.parseInt(paging);
			}*/
			//int maxRecord = Integer.parseInt(HelloClinicResourceBundle.getValue("pagination.size"));
			//int startingRecordIndex = paginationPageValues(page, maxRecord);
			//loginBO.setRecordIndex(startingRecordIndex);
			//loginBO.setMaxRecord(maxRecord);
			//loginBO.setPagination("pagination");
			AdminLoginBO adminLoginBO = adminService.retrieveAdminUsers(loginBO);
			List<AdminLoginBO> adminUserList = adminLoginBO.getAdminUserList();
			// Retrieve total admin user count
			//long retrieveAdminUsersCount = adminService.retrieveAdminUsersCount(adminLoginBO);

			if (null != adminUserList && adminUserList.size() != 0) {
				return adminUserList;
			//	model.addAttribute("AdminUser", PaginationClass.paginationLimitedRecords(page, adminUserList, maxRecord,
					//	retrieveAdminUsersCount));

			} else {
				//model.addAttribute("InfoMessage", HelloClinicResourceBundle.getValue("Validate.Profile"));
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}
	@RequestMapping(value = { "/admin-user-edit/{id}" }, method = RequestMethod.GET)
	public AdminLoginBO editAdminUser(@PathVariable String id,Model model, HttpServletRequest request) throws HeloclinicException {

		String value = CheckSeesion(request);
		if (value != null) {
		//	return value;
		}
		//String id = request.getParameter("id");
		long editId = Long.parseLong(id);
		AdminLoginBO loginBO = new AdminLoginBO();
		loginBO.setId(Long.parseLong(id));
		AdminLoginBO adminLoginBO = adminService.retrieveAdminUsers(loginBO);
		List<AdminLoginBO> adminUserList = adminLoginBO.getAdminUserList();

		try {
			for (AdminLoginBO bo : adminUserList) {
				if (editId == bo.getId()) {
					//model.addAttribute("EditAdminUser", bo);
					//model.addAttribute("page_title",
							//messageSource.getMessage("admin.edit.profile", null, request.getLocale()));
					return bo;
				}
			}
		} catch (NullPointerException ne) {
			ne.printStackTrace();
		}
		//retrieveAdminUser(model, request);
		model.addAttribute("type", "edit");
		return null;
	}
	
	@PostMapping("/admin-user-edit")
	public boolean updateUser(@RequestBody AdminLoginBO loginBO){

		try {

			//String value = CheckSeesion(request);
			//if (value != null) {
			//	return value;
			//}

			/*if (result.hasErrors()) {
				retrieveAdminUser(model, request);
				model.addAttribute("type", "edit");
				model.addAttribute("EditAdminUser", loginBO);
				model.addAttribute("page_title",
						messageSource.getMessage("admin.edit.profile", null, request.getLocale()));
				return "add-admin-user";
			}*/

			String passwordEnc = EncryptAndDecrypt.encrypt(loginBO.getPassword(), salt);
			loginBO.setPassword(passwordEnc);
			boolean isStatus = adminService.editAdminUser(loginBO);
			if (isStatus) {
				/*model.addAttribute("message", "Admin User " + loginBO.getEmailAddress() + " "
						+ HelloClinicResourceBundle.getValue("Validate.Update.Success"));
				return "redirect:/add-admin-user.html";*/
				return true;
			} else {
				//retrieveAdminUser(model, request);
				/*model.addAttribute("type", "edit");
				model.addAttribute("EditAdminUser", loginBO);
				model.addAttribute("errormessage", "Admin User " + loginBO.getEmailAddress() + " "
						+ HelloClinicResourceBundle.getValue("Validate.Update.Failure"));
				model.addAttribute("page_title",
						messageSource.getMessage("admin.edit.profile", null, request.getLocale()));
				return "add-admin-user.html";*/
				return false;
			}

		} catch (Exception he) {
			//LOGGER.debug(he.getMessage() + he);
			he.printStackTrace();
		}
		return false;

		
	}
	@RequestMapping(value = "/admin-user-delete/{id}", method = RequestMethod.GET)
	public boolean deleteAdminUser(@PathVariable String id,Model model, HttpServletRequest request) throws FileNotFoundException {

		
		AdminLoginBO adminLoginBO = new AdminLoginBO();
		long deletedId = Long.parseLong(id);
		//HttpSession session = request.getSession();
		long loginId = 1;
		try {
			adminLoginBO.setId(deletedId);
			adminLoginBO.setModified(new Date());
			adminLoginBO.setIsDeleted(false);
			adminLoginBO.setModifiedBy(loginId);
			adminLoginBO = adminService.deleteAdminUser(adminLoginBO);
			if (null != adminLoginBO.getResponse()) {
				//model.addAttribute("message", adminLoginBO.getResponse());
				return true;

			} else {
				//model.addAttribute("errormessage", HelloClinicResourceBundle.getValue("Validate.Delete"));
				return false;
			}
		} catch (Exception e) {

		}
		return false;
	}

	public String CheckSeesion(HttpServletRequest request) {
		HttpSession session = request.getSession();
		String value = null;
		if (null == session.getAttribute("id")) {
			value = "redirect:/admin-sign-in";
		}
		return value;

	}
}
