package com.elab.controller;

import java.awt.image.BufferedImage;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.OutputStream;
import java.math.BigDecimal;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.imageio.ImageIO;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import javax.validation.Valid;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.MessageSource;
import org.springframework.context.annotation.Scope;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.multipart.commons.CommonsMultipartFile;

import com.elab.exception.HeloclinicException;

import com.elab.model.PaginationBO;
import com.elab.model.TemplateBO;
import com.elab.model.TestBO;
import com.elab.model.TestHeadBO;
import com.elab.model.TestTypeBO;
import com.elab.service.LabService;
import com.elab.utils.HelloClinicResourceBundle;
import com.elab.utils.PaginationClass;
import com.elab.utils.SaveImagesToFolder;
@RestController
@RequestMapping("/api")
@CrossOrigin("http://localhost:4200")
@Scope("session")
public class LabController {
	private static final Logger LOGGER = Logger.getLogger(LabController.class);

	@Autowired
	LabService labService;

	//@Autowired
	//	private PatientDao dao;

	@Autowired
	private MessageSource messageSource;

	//private List<BookAppointmentBO> appointmentBOList;

	//private List<AppointmentStatusBO> statusList;

	private List<Long> patientTestList;

	//AppointmentStatusBO appointmentStatusBO;

	String salt = "this is a simple clear salt";

	//UploadFormBO upload;

	long appointmentId;
	//	int maxRecord=1;

	//@Autowired
	//private SendEmailService emailManager;
	MultipartFile imageFile;
	SaveImagesToFolder saveImages = new SaveImagesToFolder();
	@RequestMapping(value = "/create-test-type/{page}/{seachElement}", method = RequestMethod.GET)
	public List<TestTypeBO> createTestType(@PathVariable String page,@PathVariable String seachElement,Model model,
			HttpServletRequest request) {
		try {
			// check If the admin session object is open or not.
			/*String value = CheckSeesion(request);
			if (value != null) {
				return value;
			}*/
			String searchCriteriaValue = null;
			if (null != seachElement && !seachElement.equals("null")) {
				searchCriteriaValue = seachElement;
				//model.addAttribute("searchCriteriaValue", searchCriteriaValue);
			}
			else{
				searchCriteriaValue=null;
			}
			if (null != request.getParameter("message")) {
				String message = request.getParameter("message");
				model.addAttribute("message", message);
			}
			if (null != request.getParameter("InfoMessage")) {
				String message = request.getParameter("InfoMessage");
				model.addAttribute("InfoMessage", message);
			}
			if (null != request.getParameter("errormessage")) {
				String message = request.getParameter("errormessage");
				model.addAttribute("errormessage", message);
			}
			/*
			 * Retrieve the existed Test type list from the database.
			 */
			request.setAttribute("page", page);
			List<TestTypeBO> testTypeList=retrieveTestType(model, request, searchCriteriaValue);
			if(null!=testTypeList&&testTypeList.size()>0){
				return testTypeList;
			}
		} catch (Exception ex) {
			LOGGER.debug(ex.getMessage() + ex);
		}
		/*model.addAttribute("type", "add");
		model.addAttribute("testType", new TestTypeBO());
		model.addAttribute("page_title", messageSource.getMessage(
				"admin.create.blog.category", null, request.getLocale()));*/
		return null;
	}
	@GetMapping("/get-pagination/{page}/{totalRecord}")
	public List<PaginationBO> getPagination(@PathVariable String page, @PathVariable String totalRecord){
		int maxRecord;
		try {
			maxRecord = Integer.parseInt(HelloClinicResourceBundle.getValue("pagination.size"));

			List<PaginationBO> pagination= PaginationClass
					.paginationLimitedRecords(Long.parseLong(page),
							maxRecord,
							Long.parseLong(totalRecord));
			return pagination;
		} catch (NumberFormatException | FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return null;

	}
	@RequestMapping(value = { "/create-test-type" }, method = RequestMethod.POST)
	public TestTypeBO createTestType(
			@RequestBody TestTypeBO testTypeBO,
			BindingResult result, Model model, HttpServletRequest request)
					throws FileNotFoundException {
		try {
			/*String value = CheckSeesion(request);
			if (value != null) {
				return value;
			}*/
			//HttpSession session = request.getSession();
			//	long id = (Long) session.getAttribute("id");
			/*if (result.hasErrors()) {
				model.addAttribute("page_title",
						messageSource.getMessage("admin.create.blog.category",
								null, request.getLocale()));
				retrieveTestType(model, request, null);
				model.addAttribute("type", "add");
				return "create-test-type";
			}*/
			long id=1;
			testTypeBO.setCreatedBy(id);
			testTypeBO.setModifiedBy(id);
			testTypeBO.setIsDeleted(true);
			if (labService.findTestType(testTypeBO.getTestTypeName())) {

				//testTypeBO.setExistMessage(HelloClinicResourceBundle.getValue("Category.Exit"));
				testTypeBO.setExistMessage(HelloClinicResourceBundle.getValue("Category.Exit"));
				return testTypeBO;
			}
			boolean isStatus = labService
					.createTestType(testTypeBO);
			if (isStatus) {

				/*testTypeBO.setSuccessMessage( HelloClinicResourceBundle
								.getValue("Validate.Success"));*/
				testTypeBO.setSuccessMessage( HelloClinicResourceBundle
						.getValue("Validate.Success"));

			} else {
				/*testTypeBO.setErrorMessage( HelloClinicResourceBundle
						.getValue("HealthBlog.Category.Failure"));*/
				testTypeBO.setErrorMessage(HelloClinicResourceBundle
						.getValue("HealthBlog.Category.Failure"));

			}
		} catch (Exception e) {
			LOGGER.debug(e.getMessage() + e);
		}
		/*model.addAttribute("page_title", messageSource.getMessage(
				"admin.create.blog.category", null, request.getLocale()));
		//retrieveTestType(model, request, null);
		//model.addAttribute("type", "add");
		return "create-test-type";*/
		return testTypeBO;
	}

	private List<TestTypeBO> retrieveTestType(Model model, HttpServletRequest request, String searchCriteriaValue) {
		// TODO Auto-generated method stub

		try {
			int page = 1;
			String paging = (String) request.getAttribute("page");
			if (null != paging && !paging.equals("0")){
				page = Integer.parseInt(paging);
			}
			int maxRecord = Integer.parseInt(HelloClinicResourceBundle.getValue("pagination.size"));
			/*
			 * Calculate the starting record index for dynamic page selection.
			 */
			int startingRecordIndex = paginationPageValues(page, maxRecord);

			TestTypeBO testTypeBO = new TestTypeBO();
			testTypeBO.setRecordIndex(startingRecordIndex);
			testTypeBO.setMaxRecord(maxRecord);
			testTypeBO.setPagination("pagination");
			if (null != searchCriteriaValue && !searchCriteriaValue.isEmpty()) {
				testTypeBO.setTestTypeName(searchCriteriaValue);
			}
			/*
			 * REtrieve the Test Type total count for the purpose of
			 * calculate the pagination page length.
			 */
			long testTypeCount = labService.getTestTypeCount(testTypeBO);
			/*
			 * Retrieve Test Type object list from the database.
			 */
			testTypeBO.setTotalRecords(testTypeCount);
			List<TestTypeBO> testTypeList = labService.retrieveTestType(testTypeBO);
			if (null != testTypeList && testTypeList.size() > 0) {
				model.addAttribute("testTypeSearch", testTypeBO);
				model.addAttribute("TestTypeList", PaginationClass
						.paginationLimitedRecords(page,
								testTypeBO.getMaxRecord(),
								testTypeCount));
				return testTypeList;
				//return testTypeLists;
			} else {
				/*model.addAttribute("testTypeSearch",
						new TestTypeBO());
				model.addAttribute("InfoMessage",
						HelloClinicResourceBundle.getValue("Validate.Norecord"));*/
			}
			/*model.addAttribute("paginationSize",
					testTypeBO.getMaxRecord());*/
		} catch (Exception ex) {
			LOGGER.debug(ex.getMessage() + ex);
		}
		return null;


	}
	public static int paginationPageValues(int pageid, int recordPerPage) {
		int pageRecords = 0;
		if (pageid == 1) {
			pageRecords = 0;
		} else {
			pageRecords = (pageid - 1) * recordPerPage + 1;
			pageRecords = pageRecords - 1;
		}
		return pageRecords;
	}
	@RequestMapping(value = "/edit-test-type/{testTypeId}", method = RequestMethod.GET)
	public TestTypeBO edittestType(@PathVariable String testTypeId, Model model, HttpServletRequest request)
			throws FileNotFoundException {

		long id = Long.parseLong(testTypeId);
		try {
			// retrieve Test type based on id
			TestTypeBO blogCategory = labService.getTestType(id);
			if (null != blogCategory) {
				/*	model.addAttribute("editTestType", blogCategory);
				model.addAttribute("page_title", messageSource.getMessage(
						"admin.edit.blog.category", null, request.getLocale()));*/
				return blogCategory;
			}
			//	retrieveTestType(model, request, null);
		} catch (Exception e) {
			LOGGER.debug(e.getMessage() + e);
		}
		return null;

	}
	@RequestMapping(value = "/edit-test-type/{adminId}", method = RequestMethod.POST)
	public TestTypeBO editTestType(@PathVariable String adminId,
			@Valid @RequestBody TestTypeBO testTypeBO,
			BindingResult result, Model model, HttpServletRequest request)
					throws FileNotFoundException {

		//HttpSession session = request.getSession();
		long id = Long.parseLong(adminId);
		try {

			testTypeBO.setCreatedBy(id);
			testTypeBO.setModifiedBy(id);
			if (labService.findTestType(testTypeBO.getTestTypeName())) {

				testTypeBO.setExistMessage("TestTypeName is Already Exist");
				return testTypeBO;
			}
			boolean isStatus = labService
					.editTestType(testTypeBO);
			if (isStatus) {
				testTypeBO.setSuccessMessage("TestType Name is Updated Successfully");
				return testTypeBO;
			} else {
				testTypeBO.setErrorMessage("TestType Name is Update Failed");
				return testTypeBO;
			}
		} catch (Exception e) {
			LOGGER.debug(e.getMessage() + e);
		}
		return null;
	}
	@RequestMapping(value = "/delete-test-type/{testTypeId}/{adminId}", method = RequestMethod.GET)
	public boolean deleteTestType(@PathVariable String testTypeId,@PathVariable String adminId,Model model,
			HttpServletRequest request) throws FileNotFoundException {
		//String id = request.getParameter("id");
		TestTypeBO testTypeBO = new TestTypeBO();
		long deletedId = Long.parseLong(testTypeId);
		//HttpSession session = request.getSession();
		long loginId = Long.parseLong(adminId);
		try {
			testTypeBO.setId(deletedId);
			testTypeBO.setModified(new Date());
			testTypeBO.setIsDeleted(false);
			testTypeBO.setModifiedBy(loginId);
			testTypeBO = labService.deleteTestType(testTypeBO);
			if (null != testTypeBO.getResponse()) {
				return true;
			} else {
				return false;
			}
		} catch (Exception e) {
			LOGGER.debug(e.getMessage() + e);
		}
		return false;
	}
	@GetMapping("/get-testType")
	public List<String> getTestType(){
		List<String> testTypeList=RetrieveTestTypeNames();
		return testTypeList;

	}
	@RequestMapping(value = "/create-test-head/{page}/{seachElement}", method = RequestMethod.GET)
	public List<TestHeadBO> createTestHead(@PathVariable String page,@PathVariable String seachElement,Model model, HttpServletRequest request) {
		/*String value = CheckSeesion(request);
		if (value != null) {
			return value;
		}*/
		/*if (null != request.getParameter("message")) {
			String message = request.getParameter("message");
			model.addAttribute("message", message);
		}
		if (null != request.getParameter("errormessage")) {
			String message = request.getParameter("errormessage");
			model.addAttribute("errormessage", message);
		}*/
		try {

			String searchCriteriaValue = null;
			if (null != seachElement && !seachElement.equals("null")) {
				searchCriteriaValue = seachElement;
				//model.addAttribute("searchCriteriaValue", searchCriteriaValue);
			}
			request.setAttribute("page", page);
			List<TestHeadBO> testHeadList=retrieveTestHead(model, request, searchCriteriaValue);
			if(null!=testHeadList&&testHeadList.size()>0){
				return testHeadList;
			}
		} catch (Exception e) {
			LOGGER.debug(e.getMessage() + e);
		}

		return null;
	}

	@RequestMapping(value = { "/create-test-head/{adminId}" }, method = RequestMethod.POST)
	public TestHeadBO createTestHead(
			@PathVariable String adminId, @RequestBody TestHeadBO testHeadBO,
			BindingResult result, Model model, HttpServletRequest request) {
		//HttpSession session = request.getSession();
		long id = Long.parseLong(adminId);
		try {
			/*String value = CheckSeesion(request);
			if (value != null) {
				return value;
			}*/

			testHeadBO.setCreatedBy(id);
			testHeadBO.setModifiedBy(id);
			testHeadBO.setIsDeleted(true);
			testHeadBO.setTestTypeId(TestTypeId(testHeadBO.getTestType()));
			if (labService.findTestHeadName(testHeadBO)) {
				//RetrieveTestTypeNames(model);
				testHeadBO.setExistMessage("TestHead Name is already Exist");
				return testHeadBO;
			}
			boolean isStatus = labService.createTestHead(testHeadBO);
			if (isStatus) {
				testHeadBO.setSuccessMessage("TestHead Name Created Successfully");
				return testHeadBO;
			} else {
				testHeadBO.setErrorMessage(HelloClinicResourceBundle
						.getValue("HealthBlog.Title.Failure"));
				/*model.addAttribute("errormessage", HelloClinicResourceBundle
						.getValue("HealthBlog.Title.Failure"));
				retrieveTestHead(model, request, null);*/
				return testHeadBO;
			}
		} catch (Exception e) {
			LOGGER.debug(e.getMessage() + e);
		}

		return null;
	}

	private List<TestHeadBO> retrieveTestHead(Model model,
			HttpServletRequest request, String searchCriteriaValue){
		model.addAttribute("searchTestHead", new TestHeadBO());
		try {
			int page = 1;
			String paging = (String) request.getAttribute("page");
			if (null != paging && !paging.equals("0")){
				page = Integer.parseInt(paging);
			}
			int maxRecord = Integer.parseInt(HelloClinicResourceBundle
					.getValue("pagination.size"));
			int startingRecordIndex = paginationPageValues(page, maxRecord);
			TestHeadBO testHeadBO = new TestHeadBO();
			testHeadBO.setRecordIndex(startingRecordIndex);
			testHeadBO.setMaxRecord(maxRecord);
			testHeadBO.setPagination("pagination");
			if (null != searchCriteriaValue && !searchCriteriaValue.isEmpty()) {
				testHeadBO.setSearchElement(searchCriteriaValue);
			}
			long totalTestHeadCount = labService
					.getTestHeadCount(testHeadBO);
			testHeadBO.setTotalRecords(totalTestHeadCount);
			List<TestHeadBO> testHeadList = labService
					.retrieveTestHead(testHeadBO);
			if (null != testHeadList && testHeadList.size() > 0) {
				/*	model.addAttribute("searchTestHead", testHeadBO);
				model.addAttribute("TestHeadList", PaginationClass
						.paginationLimitedRecords(page,
								testHeadBO.getMaxRecord(),
								totalTestHeadCount));*/
				return testHeadList;
			} else {
				/*model.addAttribute("InfoMessage",
						HelloClinicResourceBundle.getValue("Validate.Norecord"));*/
				return null;
			}
			/*model.addAttribute("paginationSize", maxRecord)*/
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}

	private List<String> RetrieveTestTypeNames()  {

		List<String> testTypeNames = labService
				.retrieveTestTypeNameList();
		if (testTypeNames != null && testTypeNames.size() > 0) {
			return testTypeNames;
		}
		return testTypeNames;
	}
	private long TestTypeId(String testTypeName) {
		long id = 0;
		TestTypeBO categoryBO = labService.getTestTypeByName(testTypeName);
		if (null != categoryBO) {
			id = categoryBO.getId();
		}
		return id;
	}
	@RequestMapping(value = "/edit-test-head/{testHeadId}", method = RequestMethod.GET)
	public TestHeadBO editTestHead(@PathVariable String testHeadId,Model model, HttpServletRequest request) {

		long id = Long.parseLong(testHeadId);
		try {
			// retrieve TestHeadList based on id
			TestHeadBO testHeadBO = labService.getTestHeadById(id);
			if (null != testHeadBO) {
				//RetrieveTestTypeNames(model);
				return testHeadBO;
			}
			//retrieveTestHead(model, request, null);
		} catch (Exception e) {

		}

		return null;
	}

	@RequestMapping(value = "/edit-test-head/{adminId}", method = RequestMethod.POST)
	public TestHeadBO editTestHead(
			@PathVariable String adminId, @RequestBody TestHeadBO testHeadBO,
			BindingResult result, Model model, HttpServletRequest request){

		//HttpSession session = request.getSession();
		long id = Long.parseLong(adminId);
		try {

			testHeadBO.setCreatedBy(id);
			testHeadBO.setModifiedBy(id);
			testHeadBO.setTestTypeId(TestTypeId(testHeadBO.getTestType()));
			if (labService.findTestHeadName(testHeadBO)) {

				testHeadBO.setExistMessage("TestHead is Already Exist");

				return testHeadBO;



			}
			boolean isStatus = labService.editTestHead(testHeadBO);
			if (isStatus) {
				testHeadBO.setSuccessMessage("Test Head Update Successfully");
				return testHeadBO;
			} else {

				testHeadBO.setErrorMessage("Test Head Update Failed");
				return testHeadBO;
			}

		} catch (Exception e) {

		}
		return null;
	}

	@RequestMapping(value = "/delete-test-head/{testHeadId}/{adminId}", method = RequestMethod.GET)
	public boolean deleteTestHead(@PathVariable String testHeadId,@PathVariable String adminId,Model model, HttpServletRequest request)
			throws FileNotFoundException {
		String id = request.getParameter("id");
		TestHeadBO blogTitleBO = new TestHeadBO();
		long deletedId = Long.parseLong(testHeadId);
		//	HttpSession session = request.getSession();
		long loginId = Long.parseLong(adminId);
		try {
			blogTitleBO.setId(deletedId);
			blogTitleBO.setModified(new Date());
			blogTitleBO.setIsDeleted(false);
			blogTitleBO.setModifiedBy(loginId);
			blogTitleBO = labService.deleteTestHead(blogTitleBO);
			if (null != blogTitleBO.getResponse()) {
				blogTitleBO.setSuccessMessage(blogTitleBO.getResponse());
				return true;
			} else {
				blogTitleBO.setErrorMessage("TestHead Delete Failed");
				return false;
			}
		} catch (Exception e) {

		}
		return false;
	}
	/*@PostMapping("/post")
	public ResponseEntity<String> handleFileUpload(@RequestParam("file") MultipartFile filesssss) {
		String message = "";
		try {
			//storageService.store(file);
			//files.add(file.getOriginalFilename());

			message = "You successfully uploaded " + filesssss.getOriginalFilename() + "!";
			return ResponseEntity.status(HttpStatus.OK).body(message);
		} catch (Exception e) {
			message = "FAIL to upload " + filesssss.getOriginalFilename() + "!";
			return ResponseEntity.status(HttpStatus.EXPECTATION_FAILED).body(message);
		}
	}*/
	@PostMapping("/upload")
	public boolean uploadFile(@RequestParam("myFile") MultipartFile files,@RequestParam("username") String username){
		System.out.println("FILE::::::::::::::::"+username);
		System.out.println("FILE::::::::::::::::"+files.getName());
		imageFile=files;
		return true;

	}
	@RequestMapping(value = { "/getTestHead/{testType}/{testTypeId}" }, method = RequestMethod.GET)
	public List<String> getTestHeadTitle(@PathVariable String testType,@PathVariable String testTypeId)  {
		TestHeadBO testHeadBO= new TestHeadBO();
		if(null!=testType&&!testType.equalsIgnoreCase("null")){
			testHeadBO.setTestType(testType);
		}
		if(!testTypeId.equalsIgnoreCase("0")){
			testHeadBO.setId(Long.parseLong(testTypeId));
		}
		List<String> titleNames = labService.retrieveTestHeadName(testHeadBO);
		if (null != titleNames && titleNames.size() > 0) {
			//model.addAttribute("titles", titleNames);
			//testHead=titleNames;
			return titleNames;
		}
		return titleNames;
	}
	@RequestMapping(value = { "/create-test/{page}/{searchElement}" }, method = RequestMethod.GET)
	public List<TestBO> addTest(@PathVariable String page,@PathVariable String searchElement,Model model, HttpServletRequest request) throws FileNotFoundException {


		TestBO testBO = new TestBO();
		String search = null;
		//	RetrieveTestType(model);
		try {
			String searchCriteriaValue = null;
			if (null != searchElement && !searchElement.equals("null")) {
				searchCriteriaValue = searchElement;

				//model.addAttribute("searchCriteriaValue", searchCriteriaValue);
			}
			request.setAttribute("page", page);

			List<TestBO> testList=retriveTest(model, request, searchCriteriaValue);
			if(null!=testList&&testList.size()>0){
				return testList;
			}

		} catch (Exception ex) {
			LOGGER.debug(ex.getMessage() + ex);
		}

		return null;
	}
	private List<TestBO> retriveTest(Model model, HttpServletRequest request, String searchElement) {
		int page = 1;

		TestBO testBO = new TestBO();
		try {
			//RetrieveTestTypeNames(model);
			String paging = (String) request.getAttribute("page");
			if (null != paging && !paging.equals("0")){
				page = Integer.parseInt(paging);
			}
			int maxRecord = Integer.parseInt(HelloClinicResourceBundle.getValue("pagination.size"));
			if (null != paging) {
				page = Integer.parseInt(paging);
			}
			if (null !=searchElement) {
				testBO.setSearchElement(searchElement);
				//model.addAttribute("searchElement", testBO.getSearchElement());
			}
			int startingRecordIndex = paginationPageValues(page, maxRecord);
			testBO.setRecordIndex(startingRecordIndex);
			testBO.setMaxRecord(maxRecord);
			testBO.setPagination("pagination");
			long totalTestCount = labService.totalTestCount(testBO);
			testBO.setTotalRecords(totalTestCount);
			TestBO test = labService.retrieveTests(testBO);
			List<TestBO> testBOList = test.getAllTestBOList();

			if (null != testBOList && testBOList.size() != 0) {
				return testBOList;
				/*model.addAttribute("viewTest",
						PaginationClass.paginationLimitedRecords(page, testBOList, maxRecord, totalTestCount));*/
			} else {
				// retrieve all lab and set to the model.
				/*	model.addAttribute("page_title",
						messageSource.getMessage("admin.create.test", null, request.getLocale()));
				model.addAttribute("InfoMessage", HelloClinicResourceBundle.getValue("Validate.search.Test"));*/

			}
			if (null == testBOList && testBOList.size() == 0 && null == testBO.getSearchElement()
					&& testBO.getSearchElement().isEmpty()) {
				//model.addAttribute("InfoMessage", HelloClinicResourceBundle.getValue("Validate.Retrieve.Test"));
			}


		} catch (Exception he) {
			LOGGER.debug(he.getMessage() + he);
		}
		return null;
	}

	/**
	 * This method is used to add the testName in a database
	 * 
	 * @param testBO
	 * @param result
	 * @param model
	 * @param request
	 * @return
	 * @throws Exception
	 */
	private long TestHeadId(String testHeadName) {
		long id = 0;
		TestHeadBO categoryBO = labService.getTestHeadByName(testHeadName);
		if (null != categoryBO) {
			id = categoryBO.getId();
		}
		return id;
	}

	@RequestMapping(value = { "/create-test/{adminId}" }, method = RequestMethod.POST)
	public TestBO addTest(@PathVariable String adminId,@RequestParam("myFile") MultipartFile files,@RequestParam("username") String username,HttpServletRequest request) throws Exception {

      String[] data=username.split(",");
      TestBO testBO=new TestBO();
		//HttpSession session = request.getSession();
		long id = Long.parseLong(adminId);
		String imageName = null;
		try {

			testBO.setTestTypeId(TestTypeId(data[0]));
			testBO.setTestHeadId(TestHeadId(data[1]));
			if (labService.findTest(data[2])) {
				//model.addAttribute("InfoMessage", HelloClinicResourceBundle.getValue("Validate.TestName"));
				testBO.setExistMessage(HelloClinicResourceBundle.getValue("Validate.TestName"));
				return testBO;
			}
			if (!files.isEmpty()) {
				long imagelatestsquence = labService.imagelatestSequence("test_id", "test");
				String image_content = files.getContentType();
				String temp[] = image_content.split("/");
				imageName = (imagelatestsquence + 1) + "." + temp[1];
				testBO.setImageName(imageName);
			}
			if (!files.isEmpty()) {
				String str = imagevalied(files);
				if (null != str) {
					testBO.setErrorMessage(HelloClinicResourceBundle.getValue("Validate.Image"));
					/*model.addAttribute("errormessage", HelloClinicResourceBundle.getValue("Validate.Image"));
					model.addAttribute("page_title",
							messageSource.getMessage("admin.create.blog.article", null, request.getLocale()));
					model.addAttribute("type", "add");
					retriveTest(model, request, null);
					model.addAttribute("testSearch", new TestBO());
					model.addAttribute("test", testBO);
					return "add-test";*/
				}
			}
			//testBO.setImageName(imageName);
			testBO.setCreatedBy(id);
			testBO.setModifiedBy(id);
			testBO.setIsDeleted(true);
			testBO.setAmount(BigDecimal.valueOf(Long.valueOf(data[6])));
			testBO.setMethod(data[4]);
			testBO.setUnits(data[5]);
			testBO.setNormalRange(data[3]);
			testBO.setTestDescription(data[7]);
			testBO.setTestName(data[2]);
			boolean isStatus = labService.addTest(testBO);
			if (isStatus) {

				if (!files.isEmpty()) {
					String imagePath = HelloClinicResourceBundle.getValue("test.images.path");
					saveImages.saveImageToFolder(imageName, files, imagePath);
				}

				testBO.setSuccessMessage("Test  " + " " + testBO.getTestName() + " "
						+ HelloClinicResourceBundle.getValue("Validate.Success"));
				return testBO;
			} else {
				testBO.setErrorMessage("Test " + testBO.getTestName() + HelloClinicResourceBundle.getValue("Validate.Failure"));
				return testBO;
			}
		} catch (Exception he) {
			LOGGER.debug(he.getMessage() + he);
			he.printStackTrace();
		}
		return null;
	}
	public String imagevalied(MultipartFile profileImage) {
		String str = null;
		if (profileImage.getContentType().equals("image/jpeg") || profileImage.getContentType().equals("image/jpg")
				|| profileImage.getContentType().equals("image/png")) {

		} else {
			str = "Only jpeg,jpg,png formats are allowed  ";

		}
		return str;
	}
	// ***************** This method is used to edit the
	// test*****************************//

	/**
	 * This method is used to add the testName in a database
	 * 
	 * @param model
	 * @param request
	 * @return
	 * @throws FileNotFoundException
	 * @throws HeloclinicException
	 */
	@RequestMapping(value = { "/edit-test/{testId}" }, method = RequestMethod.GET)
	public TestBO editTest(@PathVariable String testId,Model model, HttpServletRequest request) throws FileNotFoundException, HeloclinicException {

		//model.addAttribute("type", "edit");
		//RetrieveTestTypeNames(model);
		// retrieveTests(model, request);
		//retriveTest(model, request, null);

		//model.addAttribute("test", new TestBO());
		//String id = request.getParameter("id");
		long testid = Long.parseLong(testId);
		try {
			TestBO testBO = new TestBO();
			testBO.setId(testid);
			List<TestBO> testBOList = labService.adminRetrieveTests(testBO);
			for (TestBO bo : testBOList) {
				if (testid == bo.getId()) {
					return bo;
					//testbo = bo;
				}
			}
			//TestHeadBO testHeadBO= new TestHeadBO();
			/*testHeadBO.setTestType(testbo.getTestTypeName());
			List<String> titleNames = labService.retrieveTestHeadName(testHeadBO);
			if (null != titleNames && titleNames.size() > 0) {
				model.addAttribute("titles", titleNames);

			}*/
		} catch (NullPointerException ne) {
			LOGGER.debug(ne.getMessage() + ne);
		}
		//model.addAttribute("testSearch", new TestBO());

		return null;
	}





	/**
	 * This method is used to update the testName
	 * 
	 * @param testBO
	 * @param result
	 * @param model
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(value = { "/edit-test" }, method = RequestMethod.POST)
	public TestBO editTest(@RequestBody TestBO testBO,
			HttpServletRequest request) throws Exception {

		try {
			//	RetrieveTestTypeNames(model);

			String imageName = "elab.jpg";
			//model.addAttribute("type", "edit");

			//retriveTest(model, request, null);
			testBO.setTestTypeId(TestTypeId(testBO.getTestTypeName()));
			testBO.setTestHeadId(TestHeadId(testBO.getTestHead()));

			/*if (!image.isEmpty()) {
				testBO.setCommonsMultipartFile(image);
				long imagelatestsquence = labService.imagelatestSequence("test_id", "test");
				String image_content = image.getContentType();
				String temp[] = image_content.split("/");
				imageName = (imagelatestsquence) + "." + temp[1];
				testBO.setImageName(imageName);
			}*/
			testBO.setImageName(imageName);
			boolean isStatus = labService.editTest(testBO);
			if (isStatus) {
				testBO.setSuccessMessage("Test Updated Successfully");
				return testBO;
			} else {

				testBO.setErrorMessage("Test Update Failed");
				return testBO;
			}
		} catch (Exception he) {
			LOGGER.debug(he.getMessage() + he);
		}
		return null;
	}

	@RequestMapping(value = "/view-test-details/{testid}", method = RequestMethod.GET)
	public TestBO viewTest(@PathVariable String testid,Model model, HttpServletRequest request,HttpSession session) throws HeloclinicException, FileNotFoundException {
		long testId =0;
		if(null!=testid){
			//String id = request.getParameter("testId");
			testId = Long.parseLong(testid);
		}
		try {
			TestBO test = new TestBO();
			test.setId(testId);
			List<TestBO> testBOList = labService.adminRetrieveTests(test);
			if(null!=testBOList&&testBOList.size()>0){
				for (TestBO bo : testBOList) {
					if (testId == bo.getId()) {
						return bo;

					}
				}
			}
			else{
				model.addAttribute("InfoMessage", HelloClinicResourceBundle.getValue("Validate.Norecord"));
			}

		} catch (NullPointerException ne) {
			LOGGER.debug(ne.getMessage() + ne);
		}

		/*if(null!=session.getAttribute("id")&&null!=session.getAttribute("userType")){
			String userType=(String)session.getAttribute("userType");
			if(userType.equalsIgnoreCase("patient")){
				return "view-patient-test-details";
			}
			else if(userType.equalsIgnoreCase("Super Admin")){
				return "view-admin-test-details";
			}
		}*/
		/*if(null!=session.getAttribute("adminId")){
			model.addAttribute("userType", "admin");
		}*/

		return null;

	}

	// ************ this method is used to delete the test
	// *********************//

	@RequestMapping(value = "/admin-delete-test/{testId}/{adminId}", method = RequestMethod.GET)
	public boolean deleteTest(@PathVariable String testId,@PathVariable String adminId,Model model, HttpServletRequest request) throws FileNotFoundException {
		//	String id = request.getParameter("id");
		TestBO testBO = new TestBO();
		long deletedId = Long.parseLong(testId);
		//HttpSession session = request.getSession();
		long loginId = Long.parseLong(adminId);
		try {
			testBO.setId(deletedId);
			testBO.setModified(new Date());
			testBO.setIsDeleted(false);
			testBO.setModifiedBy(loginId);
			testBO = labService.deleteTest(testBO);
			if (null != testBO.getResponse()) {
				return true;
			} else {
				return false;
			}
		} catch (Exception e) {
			LOGGER.debug(e.getMessage() + e);
		}
		return false;
	}
	@RequestMapping(value = "/read_images", method = RequestMethod.GET)
	public void readImageFromlocalFolder(Model model, HttpServletRequest request, HttpServletResponse response) {

		try {
			String imageName = request.getParameter("imgName");
			String type = request.getParameter("type");
			String imagePath = null;
			if (type.equalsIgnoreCase("healthblog")) {
				String image = HelloClinicResourceBundle.getValue("hblog.image.path");
				// imagePath = image.replace("/", "\\");
				imagePath = image;
			} else if (type.equalsIgnoreCase("healtips")) {
				String image = HelloClinicResourceBundle.getValue("hbTips.image.path");
				// imagePath = image.replace("/", "\\");
				imagePath = image;
			} else if (type.equalsIgnoreCase("product")) {
				String image = HelloClinicResourceBundle.getValue("product.image.path");
				// imagePath = image.replace("/", "\\");
				imagePath = image;
			} else if (type.equalsIgnoreCase("speciality")) {
				String image = HelloClinicResourceBundle.getValue("speciality.image.path");
				// imagePath = image.replace("/", "\\");
				imagePath = image;
			}

			else if (type.equalsIgnoreCase("bloodTips")) {
				String image = HelloClinicResourceBundle.getValue("bloodTips.image.path");
				// imagePath = image.replace("/", "\\");
				imagePath = image;
			} else if (type.equalsIgnoreCase("doctorprofile")) {
				String image = HelloClinicResourceBundle.getValue("doctorprofile.image.path");
				// imagePath = image.replace("/", "\\");
				imagePath = image;
			} else if (type.equalsIgnoreCase("doctorsignature")) {
				String image = HelloClinicResourceBundle.getValue("doctorsignature.image.path");
				// imagePath = image.replace("/", "\\");
				imagePath = image;
			} else if (type.equalsIgnoreCase("test")) {
				String image = HelloClinicResourceBundle.getValue("test.images.path");
				// imagePath = image.replace("/", "\\");
				imagePath = image;
			}
			response.setContentType("image/jpeg, image/jpg, image/png, image/gif");
			File f = null;
			try {
				f = new File(imagePath + imageName);
				if (f.exists()) {
					BufferedImage bi = ImageIO.read(f);
					OutputStream out = response.getOutputStream();
					ImageIO.write(bi, imageName.split("\\.")[1], out);
					out.close();
				}
			} catch (FileNotFoundException fe) {
				LOGGER.debug("File is not exist or access is restricted:" + imagePath + imageName);
			} catch (IOException ie) {
				LOGGER.debug("reading file image has problem:" + imagePath + imageName);
			}

		} catch (Exception ex) {
			if (LOGGER.isDebugEnabled()) {
				LOGGER.debug("Read image from local folder has failed:" + ex.getMessage());
			}
			LOGGER.info("Read image from local folder has failed:" + ex.getMessage());
		}
	}

	@GetMapping("/get-testTypeName")
	public List<TestTypeBO> getTestTypeName(){
		List<TestTypeBO> testTypeNames = labService.retrieveTestTypeBO();
		if (testTypeNames != null && testTypeNames.size() > 0) {
			return testTypeNames;
		}
		return testTypeNames;

	}
	@RequestMapping(value = { "/getTestName/{testType}/{testHead}" }, method = RequestMethod.GET)
	public List<TestBO> getTestName(
			@PathVariable String testType,@PathVariable String testHead, Model model)  {
		TestBO testBO = new TestBO();
		testBO.setTestTypeId(Long.parseLong(testType));
		testBO.setTestHead(testHead);
		List<TestBO> testNameList = labService.retriveTestName(testBO);
		if (null != testNameList && testNameList.size() > 0) {
			return testNameList;
		}
		return null;
	}
	@RequestMapping(value = "getTestAmount/{testName}", method = RequestMethod.GET)
	public TestBO amount(@PathVariable String testName,Model model, HttpServletRequest request) {

		if (null != testName) {

			TestBO testBO=new TestBO();
			testBO.setId(Long.parseLong(testName));
			//Long testid = Long.parseLong(testId);
			TestBO retrive = labService.retriveTestAmount(testBO);
			return retrive;
		}
		return null;

	}
	@RequestMapping(value = "create-template", method = RequestMethod.POST)
	public TemplateBO createTemplate(@RequestBody TemplateBO templateBO,
			BindingResult result, Model model, HttpServletRequest request) throws Exception {
		HttpSession session = request.getSession();	
		//The check Template Name is Same name is return create Template.
		if(null!=templateBO){
			boolean isSates=labService.retriveTemplate(templateBO);
			if(isSates){

				templateBO.setExistMessage(HelloClinicResourceBundle.getValue("Category.Exit"));
				return templateBO;
			}
		}
		//The check Template Code is Same Code is return create Template.
		if(null!=templateBO){
			boolean isSates=labService.retriveTemplateCode(templateBO);
			if(isSates){
				model.addAttribute("infoMessage",
						HelloClinicResourceBundle.getValue("Category.Exit.Code"));
				templateBO.setExistMessage(HelloClinicResourceBundle.getValue("Category.Exit.Code"));
				return templateBO;
			}
		}
		//	RetrieveTestType(model);
		Boolean temp = false;
		Long adminId = 1L;		
		//adminBookAppointment = new BookAppointmentBO();

		//fetchtestName(model);

		templateBO.setModified(new Date());
		templateBO.setModifiedBy(adminId);
		templateBO.setCreatedBy(adminId);	

		if (null != session.getAttribute("globalTestlist")) {
			templateBO.setTestList((List<TestBO>) session.getAttribute("globalTestlist"));
		}
		List<TestBO> testList=new ArrayList<TestBO>();
		TestBO bo=new TestBO();

		bo.setId(Long.parseLong(templateBO.getTestName()));
		bo.setTestTypeId(Long.parseLong(templateBO.getTestTypeName()));
		testList.add(bo);
		templateBO.setTestList(testList);
		temp=labService.createTemplate(templateBO);

		if (temp) {


			templateBO.setSuccessMessage(HelloClinicResourceBundle.getValue("Validate.Success"));
			return templateBO;
		} else {

			templateBO.setErrorMessage("User " +  templateBO.getTemplateName() + HelloClinicResourceBundle.getValue("Validate.Failure"));
			return templateBO;
		}

		//return "create-template";
	}
	@RequestMapping(value = "get-testName/{testId}", method = RequestMethod.GET)		
	String addBookingTest(@PathVariable String testId,HttpServletRequest request) throws ParseException, HeloclinicException {
		String testName = null;
		if(null!=testId)
		{
			//HttpSession session = request.getSession();

			TestBO testBO = new TestBO();
			testBO.setId(Long.parseLong(testId));
			List<TestBO> testBOList = labService.adminRetrieveTests(testBO);
			testName=testBOList.get(0).getTestName();
		}
		return testName;
	}
}
