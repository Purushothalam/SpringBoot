package com.elab.dao;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.apache.log4j.Logger;
import org.hibernate.Criteria;
import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.criterion.Restrictions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.transaction.annotation.Transactional;

import com.elab.exception.HeloclinicException;
import com.elab.utils.ErrorCodes;
import com.elab.entity.AdminLoginVO;
//import com.elab.vo.PatientRegistrationVO;


public abstract class AbstractDao {
	private final Logger log = Logger.getLogger(AbstractDao.class);
	@PersistenceContext
	EntityManager entityManager;
	/*@Autowired
	private SessionFactory sessionFactory;

	protected Session getSession() {
		
		return sessionFactory.getCurrentSession();
		
	}*/

	/*public void persist(Object entity) {
		try{
		getSession().persist(entity);
		}catch(HibernateException he){
			he.printStackTrace();
		}
	}

	public long save(Object entity) throws HeloclinicException {
		
		long id = 0;
		try {
			id = (Long) getSession().save(entity);
			
		} catch (HibernateException he) {
			he.printStackTrace();
			log.debug(ErrorCodes.PT_REG_FAIL_MSG + he);
			throw new HeloclinicException(ErrorCodes.PT_REG_FAIL,
					ErrorCodes.PT_REG_FAIL_MSG);

		}
		
		return id;
	}
@Transactional
	public Object saveorupdate(Object entity) throws HeloclinicException {
		
		try {
			Session session=getSession();
			session.saveOrUpdate(entity);
			session.flush();
           
		} catch (Exception he) {
			he.printStackTrace();
			log.debug(ErrorCodes.PT_UP_FAIL_MSG + he);
			throw new HeloclinicException(ErrorCodes.PT_UP_FAIL,
					ErrorCodes.PT_UP_FAIL_MSG);

		}
		
		return entity;

	}

	public void delete(Object entity) {
		getSession().delete(entity);
	}
*/
	/*public boolean findByEmail(String entityParam, String entityParamValue)
			throws HeloclinicException {
		
		PatientRegistrationVO patientRegistrationVO = null;

		try {
			Criteria cr = getSession().createCriteria(
					PatientRegistrationVO.class);
			cr.add(Restrictions.eq(entityParam, entityParamValue));

			if (null != cr && 0 != cr.list().size()) {
				patientRegistrationVO = (PatientRegistrationVO) cr.list()
						.get(0);
			}
			if (patientRegistrationVO != null) {
				return true;
			}

		} catch (HibernateException he) {
			log.debug(ErrorCodes.PT_FIN_FAIL_MSG + he);
			throw new HeloclinicException(ErrorCodes.PT_FIN_FAIL,
					ErrorCodes.PT_FIN_FAIL_MSG);

		}
		
		return false;
	}

	public PatientRegistrationVO signIn(String emailAddress,Long mobileNumber)
			throws HeloclinicException {
		
		PatientRegistrationVO patientRegistrationVO = null;
		try {
			Criteria cr = getSession().createCriteria(
					PatientRegistrationVO.class);
			
			if(null!=emailAddress&&!emailAddress.isEmpty()&&null!=mobileNumber)
			{
				cr.add(Restrictions.eq("emailAddress", emailAddress)).add(Restrictions.eq("mobileNumber", mobileNumber));
			}
			else if(null!=emailAddress&&!emailAddress.isEmpty())
			{
				
				cr.add(Restrictions.eq("emailAddress", emailAddress));
				
			}
			else if(0!=mobileNumber&&mobileNumber>0)
			{
				cr.add(Restrictions.or(Restrictions.eq("mobileNumber", mobileNumber),Restrictions.eq("alterMobileNumber", mobileNumber)));
			}
			
			if (null != cr.list() && cr.list().size() > 0) {
				patientRegistrationVO = (PatientRegistrationVO) cr.list()
						.get(0);
			}

		} catch (HibernateException he) {
			log.debug(ErrorCodes.PT_LOG_FAIL_MSG + he);
			throw new HeloclinicException(ErrorCodes.PT_LOG_FAIL,
					ErrorCodes.PT_LOG_FAIL_MSG);
		}
		
		return patientRegistrationVO;

	}*/

	public AdminLoginVO adminSignIn(String emailAddress)
			throws HeloclinicException {
		
		AdminLoginVO adminLoginVO = null;
		try {
			Criteria cr = getSession().createCriteria(AdminLoginVO.class);
			cr.add(Restrictions.eq("isDeleted", true));
			cr.add(Restrictions.eq("emailAddress", emailAddress));
			if (null != cr.list() && cr.list().size() > 0) {
				adminLoginVO = (AdminLoginVO) cr.list().get(0);
			}

		} catch (HibernateException he) {
			he.printStackTrace();
			log.debug(ErrorCodes.PT_LOG_FAIL_MSG + he);
			throw new HeloclinicException(ErrorCodes.PT_LOG_FAIL,
					ErrorCodes.PT_LOG_FAIL_MSG);
		}
		
		return adminLoginVO;

	}
	public Session getSession() {
		// TODO Auto-generated method stub
		return entityManager.unwrap(Session.class);
		
	}

	

	

}
