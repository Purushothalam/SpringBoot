package com.elab.dao;

import java.util.List;

import com.elab.entity.AdminLoginVO;
import com.elab.model.AdminLoginBO;

public interface AdminDao {

	

	AdminLoginBO authenticate(AdminLoginBO adminLoginBO);

	AdminLoginBO retrieveProfile(AdminLoginBO loginBO);

	long addAdminUser(AdminLoginVO loginVO);

	AdminLoginVO changePassword(AdminLoginVO adminLoginVO);

	List<AdminLoginBO> retrieveAdminUsers(AdminLoginBO loginBO);

	AdminLoginVO getadminUser(long id);

	AdminLoginBO editAdminUser(AdminLoginVO loginVO);

	int deleteAdminUser(AdminLoginVO loginVO);


}
