package com.elab.dao;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.HibernateException;
import org.hibernate.Query;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Restrictions;
import org.springframework.beans.BeanUtils;
import org.springframework.stereotype.Repository;

import com.elab.exception.HeloclinicException;
import com.elab.model.AdminLoginBO;
import com.elab.service.AdminService;
import com.elab.utils.EncryptAndDecrypt;
import com.elab.utils.SuccessMsg;
import com.elab.entity.AdminLoginVO;
@Repository
public class AdminDaoImpl extends AbstractDao implements AdminDao {
	String salt = "this is a simple clear salt";
	@Override
	public AdminLoginBO authenticate(AdminLoginBO adminLoginBO) {

		AdminLoginBO loginBO = null;
		try {

			AdminLoginVO loginVO = adminSignIn(adminLoginBO.getEmailAddress());
			if (null != loginVO) {
				/*String passwordDec = EncryptAndDecrypt.decrypt(
						loginVO.getPassword(), salt);*/
				if (null!=adminLoginBO.getPassword()) {
					loginBO = new AdminLoginBO();
					loginBO.setEmailAddress(loginVO.getEmailAddress());
					loginBO.setId(loginVO.getId());
					loginBO.setStatus(true);
					loginBO.setUserType(loginVO.getUserType());
					return loginBO;
				} else {
					loginBO = new AdminLoginBO();
					loginBO.setStatus(false);
				}
			} else {
				loginBO = new AdminLoginBO();
				loginBO.setStatus(false);
			}
		} catch (Exception he) {
			//LOGGER.debug(he.getMessage() + he);

		} 

		return loginBO;
	}
	@Override
	public AdminLoginBO retrieveProfile(AdminLoginBO adminLoginBO) {

		
		List<AdminLoginVO> adminLoginVOList = new ArrayList<AdminLoginVO>();
		AdminLoginBO loginBO = null;
		SimpleDateFormat format = new SimpleDateFormat("dd-MM-yyyy hh:mm:ss");
		try {
			Criteria criteria = getSession().createCriteria(AdminLoginVO.class);
			criteria.add(Restrictions.eq("id", adminLoginBO.getId()));
			criteria.addOrder(Order.desc("id"));
			adminLoginVOList = criteria.list();
			for (AdminLoginVO adminLoginVO : adminLoginVOList) {
				loginBO = new AdminLoginBO();
				loginBO.setId(adminLoginVO.getId());
				loginBO.setIsDeleted(adminLoginVO.getIsDeleted());
				loginBO.setEmailAddress(adminLoginVO.getEmailAddress());
				loginBO.setPassword(adminLoginVO.getPassword());
				loginBO.setCreated(adminLoginVO.getCreated());
				loginBO.setModified(adminLoginVO.getModified());
				loginBO.setCreateDate(format.format(adminLoginVO.getCreated()));
				loginBO.setModifiedDate(format.format(adminLoginVO
						.getModified()));
				
			}

		} catch (HibernateException he) {

		}

		return loginBO;
	}
	@Override
	public long addAdminUser(AdminLoginVO loginVO) {
		// TODO Auto-generated method stub
		long id=(long)getSession().save(loginVO);
		return id;
	}
	@Override
	public AdminLoginVO changePassword(AdminLoginVO loginVO) {

		int result = 0;
		String changePasswordQuery = "UPDATE AdminLoginVO S set"
				+ " S.password = :password"
				+ " WHERE S.emailAddress = :emailAddress";
		// String changePasswordQuery =
		// "UPDATE PatientRegistrationVO E set E.password = :password , E.confirmPassword = :cPassword  WHERE E.emailAddress = :emailAddress";
		try {
			Query query = getSession().createQuery(changePasswordQuery);
			query.setParameter("password", loginVO.getPassword());
			query.setParameter("emailAddress", loginVO.getEmailAddress());
			result = query.executeUpdate();
			if (result != 0) {
				return loginVO;
			}
		} catch (HibernateException he) {
			he.printStackTrace();
		}

		return null;
	}
	@Override
	public List<AdminLoginBO> retrieveAdminUsers(AdminLoginBO adminLoginBO) {

		List<AdminLoginBO> adminUserBOList = new ArrayList<AdminLoginBO>();
		List<AdminLoginVO> adminUserVOList = new ArrayList<AdminLoginVO>();
		AdminLoginBO loginBO;
		SimpleDateFormat dateFormat = new SimpleDateFormat(
				"dd-MM-yyyy hh:mm:ss");
		String createDate;

		try {
			Criteria criteria = getSession().createCriteria(AdminLoginVO.class);
			if(0 != adminLoginBO.getId()) {
				criteria.add(Restrictions.eq("id", adminLoginBO.getId()));
			}

			if (null != adminLoginBO.getPagination()
					&& !adminLoginBO.getPagination().isEmpty()) {
				criteria.setFirstResult(adminLoginBO.getRecordIndex());
				criteria.setMaxResults(adminLoginBO.getMaxRecord());
			}
			criteria.add(Restrictions.eq("isDeleted", true));
			criteria.addOrder(Order.desc("id"));
			adminUserVOList = criteria.list();
			for (AdminLoginVO adminLoginVO : adminUserVOList) {
				loginBO = new AdminLoginBO();
				loginBO.setId(adminLoginVO.getId());
				loginBO.setEmailAddress(adminLoginVO.getEmailAddress());
				loginBO.setIsDeleted(adminLoginVO.getIsDeleted());
				if(null!=adminLoginBO.getUserType()){
					if (adminLoginBO.getUserType().equals("Super Admin")) {
						String passwordDec = EncryptAndDecrypt.decrypt(
								adminLoginVO.getPassword(), salt);
						loginBO.setPassword(passwordDec);
					}}
				loginBO.setUserType(adminLoginVO.getUserType());
				loginBO.setCreated(adminLoginVO.getCreated());
				loginBO.setModified(adminLoginVO.getModified());
				loginBO.setCreatedBy(adminLoginVO.getCreatedBy());
				loginBO.setModifiedBy(adminLoginVO.getModifiedBy());
				createDate = dateFormat.format(adminLoginVO.getCreated());
				loginBO.setCreateDate(createDate);
				loginBO.setModifiedDate(dateFormat.format(adminLoginVO
						.getModified()));
				adminUserBOList.add(loginBO);
			}
		} catch (HibernateException he) {
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return adminUserBOList;
	}
	@Override
	public AdminLoginVO getadminUser(long id) {AdminLoginVO adminloginvo=(AdminLoginVO)getSession().get(AdminLoginVO.class,id);
	return adminloginvo;
	}
	@Override
	public AdminLoginBO editAdminUser(AdminLoginVO adminLoginVO) {

		AdminLoginBO loginBO = null;
		try {
			loginBO = new AdminLoginBO();
			getSession().saveOrUpdate(adminLoginVO);
			BeanUtils.copyProperties(adminLoginVO, loginBO);
			loginBO.setResponse(SuccessMsg.AD_UP);
		} catch (Exception he) {
			//LOGGER.debug(he.getMessage() + he);
			//loginBO.setErrorCode(he.getErrorCode());
			//loginBO.setErrorMessage(he.getErrorMessage());
		}

		return loginBO;
	}
	@Override
	public int deleteAdminUser(AdminLoginVO adminLoginVO) {

		int result = 0;
		String deleteQuery = "UPDATE AdminLoginVO S set"
				+ " S.isDeleted = :isDeleted," + "S.modifiedBy = :modifiedBy,"
				+ "S.modified=:modified" + " WHERE S.id = :id";
		try {

			Query query = getSession().createQuery(deleteQuery);
			query.setParameter("isDeleted", adminLoginVO.getIsDeleted());
			query.setParameter("modifiedBy", adminLoginVO.getModifiedBy());
			query.setParameter("modified", adminLoginVO.getModified());
			query.setParameter("id", adminLoginVO.getId());
			result = query.executeUpdate();
		} catch (HibernateException he) {

			//LOGGER.debug(he.getMessage() + he);
		}

		return result;
	}

}
