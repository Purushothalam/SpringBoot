package com.elab.dao;

import java.util.List;

import com.elab.entity.TemplateVO;
import com.elab.entity.TestHeadVO;
import com.elab.entity.TestTypeVO;
import com.elab.entity.TestVO;
import com.elab.exception.HeloclinicException;
import com.elab.model.TemplateBO;
import com.elab.model.TestBO;
import com.elab.model.TestHeadBO;
import com.elab.model.TestTypeBO;

public interface LabDao {

	long getTestTypeCount(TestTypeBO testTypeBO);

	List<TestTypeBO> retrieveTestType(TestTypeBO testTypeBO);

	long createTestType(TestTypeVO testTypeVO);

	TestTypeVO findTestType(String testTypeName) throws HeloclinicException;

	TestTypeVO getTestType(long id);

	TestTypeBO editTestType(TestTypeVO testTypeVO);

	int deleteTestType(TestTypeBO testTypeBO);

	TestHeadVO findTestHeadName(TestHeadBO testHeadBO) throws HeloclinicException;

	long getTestHeadCount(TestHeadBO testHeadBO);

	List<TestHeadBO> retrieveTestHead(TestHeadBO testHeadBO);

	TestTypeBO getTestTypeByName(String testTypeName);

	List<String> retrieveTestTypeNameList();

	long createTestHead(TestHeadVO testHeadVO);

	TestHeadVO getTestHeadById(long id);

	TestHeadBO editTestHead(TestHeadVO testHeadVO);

	int deleteTestHead(TestHeadBO testHeadBO);

	List<String> retrieveTestHeadName(TestHeadBO testHeadBO);

	List<TestBO> retrieveTests(TestBO testBO);

	long totalTestCount(TestBO testBO);

	TestVO findTest(String testName) throws HeloclinicException;

	long addTest(TestVO testVO);

	List<TestBO> adminRetrieveTests(TestBO testBO);

	TestHeadBO getTestHeadByName(String testHeadName);

	TestVO getTest(long id);

	TestBO editTest(TestVO testVO);

	int deleteTest(TestVO testVO);

	List<TestTypeBO> retrieveTestTypeBO();

	List<TestBO> retriveTestName(TestBO testBO);

	TestVO retriveTestAmount(TestBO testBO);

	TemplateBO retriveTemplate(TemplateBO templateBO);

	TemplateBO retriveTemplateCode(TemplateBO templateBO);

	long createTemplate(TemplateVO templateVO);

	long findimageLatestSquence(String columnName, String tableName);

}
