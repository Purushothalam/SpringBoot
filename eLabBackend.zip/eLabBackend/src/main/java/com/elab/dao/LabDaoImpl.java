package com.elab.dao;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.apache.log4j.Logger;
import org.hibernate.Criteria;
import org.hibernate.HibernateException;
import org.hibernate.Query;
import org.hibernate.SQLQuery;
import org.hibernate.criterion.MatchMode;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Projections;
import org.hibernate.criterion.Restrictions;
import org.springframework.beans.BeanUtils;
import org.springframework.stereotype.Repository;

import com.elab.entity.TemplateVO;
import com.elab.entity.TestHeadVO;
import com.elab.entity.TestTypeVO;
import com.elab.entity.TestVO;
import com.elab.exception.HeloclinicException;
import com.elab.model.TemplateBO;
import com.elab.model.TestBO;
import com.elab.model.TestHeadBO;
import com.elab.model.TestTypeBO;
import com.elab.utils.ErrorCodes;
import com.elab.utils.SuccessMsg;

@Repository
public class LabDaoImpl extends AbstractDao implements LabDao{
	private final Logger LOGGER = Logger.getLogger(LabDaoImpl.class);
	@Override
	public long getTestTypeCount(TestTypeBO categoryBO) {
		long HealthBlogCategoryCount = 0;
		if(null != categoryBO.getTestTypeName()&& !categoryBO.getTestTypeName().isEmpty()){
			HealthBlogCategoryCount = (long) getSession().createCriteria(TestTypeVO.class).add(Restrictions.eq("isDeleted", true))
					.add(Restrictions.ilike("testTypeName", categoryBO.getTestTypeName(),MatchMode.ANYWHERE)).setProjection(Projections.rowCount()).uniqueResult();
		}else{
			HealthBlogCategoryCount = (long) getSession().createCriteria(TestTypeVO.class).add(Restrictions.eq("isDeleted", true))
				.setProjection(Projections.rowCount()).uniqueResult();
		}
		return HealthBlogCategoryCount;

	}

	@Override
	public List<TestTypeBO> retrieveTestType(TestTypeBO testTypeBO) {
		// TODO Auto-generated method stub
		TestTypeBO testType;
		long totalrecordCount=testTypeBO.getTotalRecords();
		List<TestTypeBO> testTypeBOList = new ArrayList<TestTypeBO>();
		List<TestTypeVO> testTypeVoList = new ArrayList<TestTypeVO>();
		Criteria criteria = null;
		SimpleDateFormat format = new SimpleDateFormat("dd-MM-yyyy hh:mm:ss");
		String createdDate;
		String modifiedDate;
		try {
			criteria = getSession().createCriteria(TestTypeVO.class);
			criteria.add(Restrictions.eq("isDeleted", true));
			criteria.addOrder(Order.desc("created"));

			if (null != testTypeBO.getTestTypeName()) {
				criteria.add(Restrictions.ilike("testTypeName", "%"
						+ testTypeBO.getTestTypeName() + "%"));
			}
			if (null != testTypeBO.getPagination()
					&& !testTypeBO.getPagination().isEmpty()) {
				criteria.setFirstResult(testTypeBO.getRecordIndex());
				criteria.setMaxResults(testTypeBO.getMaxRecord());
			}
			testTypeVoList = criteria.list();
			for (TestTypeVO testTypeVO : testTypeVoList) {
				testType = new TestTypeBO();
				BeanUtils.copyProperties(testTypeVO, testType);
				testType.setId(testTypeVO.getTestTypeId());
				testType.setTotalRecords(totalrecordCount);

				/*createdDate = format.format(testTypeVO.getCreated());
				testType.setCreated(createdDate);

				modifiedDate = format
						.format(testTypeVO.getModified());
				testType.setModified(modifiedDate);*/

				testTypeBOList.add(testType);

			}
		} catch (HibernateException he) {

		}

		return testTypeBOList;
	}

	@Override
	public long createTestType(TestTypeVO testTypeVO) {

		long id = 0;
		try {
			id = (long) getSession().save(testTypeVO);
		} catch (Exception he) {
			LOGGER.debug(he.getMessage() + he);
		}

		return id;
	}

	@Override
	public TestTypeVO findTestType(String testTypeName) throws HeloclinicException {

		TestTypeVO testVO = null;
		try {

			Criteria criteria = getSession().createCriteria(
					TestTypeVO.class);
			criteria.add(Restrictions.eq("testTypeName", testTypeName));
			criteria.add(Restrictions.eq("isDeleted", true));
			if (null != criteria.list() && criteria.list().size() > 0) {
				testVO = (TestTypeVO) criteria.list().get(0);
			}

		} catch (HibernateException he) {
			LOGGER.debug(ErrorCodes.PT_RE_FAIL);
			throw new HeloclinicException(ErrorCodes.PT_RE_FAIL,
					ErrorCodes.PT_RE_FAIL_MSG);
			//he.printStackTrace();
		}

		return testVO;

	}

	@Override
	public TestTypeVO getTestType(long id) {
		// TODO Auto-generated method stub
		TestTypeVO testTypeVO = (TestTypeVO) getSession()
				.get(TestTypeVO.class, id);
		return testTypeVO;

	}

	@Override
	public TestTypeBO editTestType(TestTypeVO testTypeVO) {

		TestTypeBO testTypeBO = null;
		try {
			testTypeBO = new TestTypeBO();
			 getSession().saveOrUpdate(testTypeVO);
			BeanUtils.copyProperties(testTypeVO, testTypeBO);
			testTypeBO.setResponse(SuccessMsg.AD_UP);
		} catch (Exception he) {
			LOGGER.debug(he.getMessage() + he);
			//testTypeBO.setErrorCode(he.getErrorCode());
			//testTypeBO.setErrorMessage(he.getErrorMessage());

		}

		return testTypeBO;
	}

	@Override
	public int deleteTestType(TestTypeBO testTypeBO) {

		int result = 0;
		String deleteQuery = "UPDATE TestTypeVO S set"
				+ " S.isDeleted= :isDeleted," + "S.modifiedBy = :modifiedBy,"
				+ "S.modified=:modified" + " WHERE S.testTypeId=:id";
		try {

			Query query = getSession().createQuery(deleteQuery);
			query.setParameter("isDeleted", testTypeBO.getIsDeleted());
			query.setParameter("modifiedBy", testTypeBO.getModifiedBy());
			query.setParameter("modified", new Date());
			query.setParameter("id", testTypeBO.getId());
			result = query.executeUpdate();
		} catch (HibernateException he) {

			LOGGER.debug(he.getMessage() + he);
			he.printStackTrace();
		}

		return result;
	}

	@Override
	public TestHeadVO findTestHeadName(TestHeadBO testHeadBO) throws HeloclinicException {
		// TODO Auto-generated method stub

		// TODO Auto-generated method stub

		TestHeadVO testHeadVO = null;
		try {

			Criteria criteria = getSession().createCriteria(
					TestHeadVO.class);
			criteria.add(Restrictions.like("testHead", testHeadBO.getTestHead()));
			criteria.createCriteria("testTypeVO").add(
					Restrictions.eq("testTypeId", testHeadBO.getTestTypeId()));
			criteria.add(Restrictions.eq("isDeleted", true));
			if (null != criteria.list() && criteria.list().size() > 0) {
				testHeadVO = (TestHeadVO) criteria.list().get(0);
			}

		} catch (HibernateException he) {
			LOGGER.debug(ErrorCodes.PT_RE_FAIL);
			throw new HeloclinicException(ErrorCodes.PT_RE_FAIL,
					ErrorCodes.PT_RE_FAIL_MSG);
		}

		return testHeadVO;
	
	}

	@Override
	public long getTestHeadCount(TestHeadBO testHeadBO) {
		long HealthBlogTitleCount =0;
		if(null != testHeadBO.getSearchElement() && !testHeadBO.getSearchElement().isEmpty()){
			HealthBlogTitleCount = (long) getSession().createCriteria(TestHeadVO.class).add(Restrictions.eq("isDeleted", true))
					.add(Restrictions.ilike("testHead", testHeadBO.getSearchElement(),MatchMode.ANYWHERE)).setProjection(Projections.rowCount()).uniqueResult();
		}else{
			HealthBlogTitleCount = (long) getSession().createCriteria(TestHeadVO.class).add(Restrictions.eq("isDeleted", true))
				.setProjection(Projections.rowCount()).uniqueResult();
		}
		return HealthBlogTitleCount;

	}

	@Override
	public List<TestHeadBO> retrieveTestHead(TestHeadBO testHeadBO) {
		// TODO Auto-generated method stub


		TestHeadBO testHead;
		List<TestHeadBO> testHeadBOList = new ArrayList<TestHeadBO>();
		List<TestHeadVO> testHeadList = new ArrayList<TestHeadVO>();
		SimpleDateFormat format = new SimpleDateFormat("dd-MM-yyyy hh:mm:ss");
		String createdDate;

		Criteria criteria = null;
		int count = 1;
		try {
			criteria = getSession().createCriteria(TestHeadVO.class);
			criteria.add(Restrictions.eq("isDeleted", true));
			criteria.addOrder(Order.desc("created"));

			if (null != testHeadBO.getTestHead()) {
				criteria.add(Restrictions.ilike("testHead", "%"
						+ testHeadBO.getTestHead() + "%"));
			}
			if (null != testHeadBO.getPagination()
					&& !testHeadBO.getPagination().isEmpty()) {
				criteria.setFirstResult(testHeadBO.getRecordIndex());
				criteria.setMaxResults(testHeadBO.getMaxRecord());
			}

			testHeadList = criteria.list();
			for (TestHeadVO testHeadVO : testHeadList) {
				testHead = new TestHeadBO();
				BeanUtils.copyProperties(testHeadVO, testHead);
				testHead.setTotalRecords(testHeadBO.getTotalRecords());
				testHead.setId(testHeadVO.getTestHeadId());
				testHead.setTestType(testHeadVO.getTestTypeVO().getTestTypeName());
				testHead.setsNo(count);
				createdDate = format.format(testHeadVO.getCreated());
				testHead.setCreatedDate(createdDate);
				testHeadBOList.add(testHead);
				count = count + 1;
			}
		} catch (HibernateException he) {

		}

		return testHeadBOList;
	
	}

	@Override
	public TestTypeBO getTestTypeByName(String testTypeName) {
		// TODO Auto-generated method stub


		Criteria criteria = null;
		try {
			criteria = getSession().createCriteria(TestTypeVO.class);
			criteria.add(Restrictions.eq("isDeleted", true));
			criteria.addOrder(Order.desc("created"));

			if (null != testTypeName) {
				criteria.add(Restrictions.ilike("testTypeName", testTypeName));
			}
			List<TestTypeVO> categoryVOList = criteria.list();
			if (null != categoryVOList && categoryVOList.size() > 0) {
				TestTypeVO testTypeVO = categoryVOList
						.get(0);
				TestTypeBO testTypeBO = new TestTypeBO();
				BeanUtils.copyProperties(testTypeVO, testTypeBO);
				testTypeBO.setId(testTypeVO.getTestTypeId());
				return testTypeBO;
			}
		} catch (HibernateException he) {

		}
		return null;
	
	}

	@Override
	public List<String> retrieveTestTypeNameList() {
		String hqlQuery = "SELECT testTypeName FROM TestTypeVO WHERE isDeleted=:status";
		Query query = getSession().createQuery(hqlQuery);
		query.setParameter("status", true);
		List<String> categoryList = query.list();
		return categoryList;
	}

	@Override
	public long createTestHead(TestHeadVO testHeadVO) {

		long id = 0;
		try {
			id = (long)getSession().save(testHeadVO);
		} catch (Exception he) {
			LOGGER.debug(he.getMessage() + he);
		}

		return id;
	}

	@Override
	public TestHeadVO getTestHeadById(long id) {
		// TODO Auto-generated method stub
		TestHeadVO testHeadVO = (TestHeadVO) getSession().get(TestHeadVO.class, id);
		return testHeadVO;
	}

	@Override
	public TestHeadBO editTestHead(TestHeadVO testHeadVO) {

		TestHeadBO testHeadBO = null;
		try {
			testHeadBO = new TestHeadBO();
			getSession().saveOrUpdate(testHeadVO);
			BeanUtils.copyProperties(testHeadVO, testHeadBO);
			testHeadBO.setResponse(SuccessMsg.AD_UP);
		} catch (Exception he) {
			LOGGER.debug(he.getMessage() + he);
			//testHeadBO.setErrorCode(he.getErrorCode());
			//testHeadBO.setErrorMessage(he.getErrorMessage());
		}

		return testHeadBO;
	}

	@Override
	public int deleteTestHead(TestHeadBO testHeadBO) {

		int result = 0;
		String deleteQuery = "UPDATE TestHeadVO S set"
				+ " S.isDeleted= :isDeleted," + "S.modifiedBy = :modifiedBy,"
				+ "S.modified=:modified" + " WHERE S.testHeadId=:id";
		try {

			Query query = getSession().createQuery(deleteQuery);
			query.setParameter("isDeleted", testHeadBO.getIsDeleted());
			query.setParameter("modifiedBy", testHeadBO.getModifiedBy());
			query.setParameter("modified", new Date());
			query.setParameter("id", testHeadBO.getId());
			result = query.executeUpdate();
		} catch (HibernateException he) {

			LOGGER.debug(he.getMessage() + he);
		}

		return result;
	}

	@Override
	public List<String> retrieveTestHeadName(TestHeadBO testHead) {
		// TODO Auto-generated method stub

		try {
			if(null!=testHead.getTestType()&&!testHead.getTestType().isEmpty()){
			String hqlQuery = "SELECT testHead FROM TestHeadVO WHERE testTypeVO.testTypeName=:testTypeName";
			Query query = getSession().createQuery(hqlQuery);
			query.setParameter("testTypeName", testHead.getTestType());
			List<String> testHeadList = query.list();
			return testHeadList;
			}
			if(0!=testHead.getId()&&testHead.getId()>0){
				String hqlQuery = "SELECT testHead FROM TestHeadVO WHERE testTypeVO.testTypeId=:testTypeId";
				Query query = getSession().createQuery(hqlQuery);
				query.setParameter("testTypeId", testHead.getId());
				List<String> testHeadList = query.list();
				return testHeadList;
			}
		} catch (Exception ex) {
			ex.printStackTrace();
		}
		return null;
	
	}

	@Override
	public List<TestBO> retrieveTests(TestBO test) {
		// TODO Auto-generated method stub


		TestBO testBO;
		List<TestBO> testBOList = new ArrayList<TestBO>();
		List<TestVO> testVOList = new ArrayList<TestVO>();
		SimpleDateFormat format = new SimpleDateFormat("dd-MM-yyyy hh:mm:ss");
		try {

			Criteria criteria = getSession().createCriteria(TestVO.class);
			criteria.add(Restrictions.eq("isDeleted", true));
			criteria.addOrder(Order.desc("testId"));
			if(null != test.getSearchElement() && !test.getSearchElement().isEmpty()){
				criteria.add(Restrictions.ilike("testName",test.getSearchElement(),MatchMode.ANYWHERE));
			}
			if (null != test.getPagination()
					&& !test.getPagination().isEmpty()) {
				criteria.setFirstResult(test.getRecordIndex());
				criteria.setMaxResults(test.getMaxRecord());
			}
			testVOList = criteria.list();
			for (TestVO testVO : testVOList) {
				testBO = new TestBO();
				BeanUtils.copyProperties(testVO, testBO);
				testBO.setId(testVO.getTestId());
				testBO.setTotalRecords(test.getTotalRecords());
				testBO.setImageName(testVO.getImageName());
				testBO.setTestHead(testVO.getTestTypeVO().getTestTypeName());
				testBO.setAmount(testVO.getAmount());
				testBO.setCreatedate(format.format(testVO.getCreated()));
				testBO.setModifiedDate(format.format(testVO.getModified()));
				testBOList.add(testBO);

			}
		} catch (HibernateException he) {
			LOGGER.debug(he.getMessage() + he);
		}

		return testBOList;
	
	}

	@Override
	public long totalTestCount(TestBO testBO) {
		long testCount =0;
		SimpleDateFormat format = new SimpleDateFormat("dd-MM-yyyy hh:mm:ss");
		try {
			if(null != testBO.getSearchElement() && !testBO.getSearchElement().isEmpty()){
				testCount = (long) getSession().createCriteria(TestVO.class).add(Restrictions.eq("isDeleted", true))
						.add(Restrictions.ilike("testName", testBO.getSearchElement(),MatchMode.ANYWHERE)).setProjection(Projections.rowCount()).uniqueResult();
			}else{
				testCount = (long) getSession().createCriteria(TestVO.class).add(Restrictions.eq("isDeleted", true))
						.setProjection(Projections.rowCount()).uniqueResult();
			}

		} catch (HibernateException he) {
			LOGGER.debug(he.getMessage() + he);

		}

		return testCount;
	}

	@Override
	public TestVO findTest(String testName) throws HeloclinicException {
		// TODO Auto-generated method stub


		TestVO testVO = null;
		try {

			Criteria criteria = getSession().createCriteria(TestVO.class);
			criteria.add(Restrictions.eq("testName", testName));
			criteria.add(Restrictions.eq("isDeleted", true));
			if (null != criteria.list() && criteria.list().size() > 0) {
				testVO = (TestVO) criteria.list().get(0);
			}

		} catch (HibernateException he) {
			LOGGER.debug(ErrorCodes.PT_RE_FAIL);
			throw new HeloclinicException(ErrorCodes.PT_RE_FAIL,
					ErrorCodes.PT_RE_FAIL_MSG);
		}

		return testVO;

	
	}

	@Override
	public long addTest(TestVO testVO) {
		// TODO Auto-generated method stub
		long id = 0;
		try {
			id =(long) getSession().save(testVO);
		} catch (Exception he) {
			LOGGER.debug(he.getMessage() + he);
		}

		return id;
	
	}

	@Override
	public List<TestBO> adminRetrieveTests(TestBO testBO) {
		// TODO Auto-generated method stub

		List<TestBO> testBOList = new ArrayList<TestBO>();
		List<TestVO> testVOList = new ArrayList<TestVO>();
		SimpleDateFormat format = new SimpleDateFormat("dd-MM-yyyy hh:mm:ss");
		try {

			Criteria criteria = getSession().createCriteria(TestVO.class);
			if(0 != testBO.getId()){
				criteria.add(Restrictions.eq("testId",testBO.getId()));

			}
			if(null != testBO.getSearchElement() && !testBO.getSearchElement().isEmpty()){
				criteria.add(Restrictions.ilike("testName",testBO.getSearchElement(),MatchMode.ANYWHERE));
			}
			criteria.add(Restrictions.eq("isDeleted", true));
			criteria.addOrder(Order.desc("testId"));
			testVOList = criteria.list();
			for (TestVO testVO : testVOList) {
				testBO = new TestBO();
				BeanUtils.copyProperties(testVO, testBO);
				testBO.setId(testVO.getTestId());
				testBO.setTestTypeName(testVO.getTestTypeVO().getTestTypeName());
				testBO.setTestHead(testVO.getTestHeadVO().getTestHead());
				testBO.setTestHeadId(testVO.getTestHeadVO().getTestHeadId());
				testBO.setCreatedate(format.format(testVO.getCreated()));
				testBO.setModifiedDate(format.format(testVO.getModified()));
				testBOList.add(testBO);
			}
		} catch (HibernateException he) {
			LOGGER.debug(he.getMessage() + he);

		}

		return testBOList;
	
	}

	@Override
	public TestHeadBO getTestHeadByName(String testHead) {
		// TODO Auto-generated method stub


		Criteria criteria = null;
		try {
			criteria = getSession().createCriteria(TestHeadVO.class);
			criteria.add(Restrictions.eq("isDeleted", true));
			criteria.addOrder(Order.desc("created"));

			if (null != testHead) {
				criteria.add(Restrictions.ilike("testHead", testHead));
			}
			List<TestHeadVO> TestHeadVOList = criteria.list();
			if (null != TestHeadVOList && TestHeadVOList.size() > 0) {
				TestHeadVO testTypeVO = TestHeadVOList
						.get(0);
				TestHeadBO testHeadBO = new TestHeadBO();
				BeanUtils.copyProperties(testTypeVO, testHeadBO);
				testHeadBO.setId(testTypeVO.getTestHeadId());
				return testHeadBO;
			}
		} catch (HibernateException he) {

		}

	return null;

	}

	@Override
	public TestVO getTest(long id) {
		// TODO Auto-generated method stub
		TestVO testVO = (TestVO) getSession()
				.get(TestVO.class, id);
		return testVO;
	}

	@Override
	public TestBO editTest(TestVO testVO) {
		// TODO Auto-generated method stub
		TestBO bo = null;
		try {
			bo = new TestBO();
			getSession().saveOrUpdate(testVO);
			BeanUtils.copyProperties(testVO, bo);
			bo.setResponse(SuccessMsg.AD_UP);
		} catch (Exception he) {
			LOGGER.debug(he.getMessage() + he);
			
		}

		return bo;
	
	}

	@Override
	public int deleteTest(TestVO testVO) {

		int result = 0;
		String deleteQuery = "UPDATE TestVO S set"
				+ " S.isDeleted = :isDeleted," + "S.modifiedBy = :modifiedBy,"
				+ "S.modified=:modified" + " WHERE S.testId = :id";
		try {

			Query query = getSession().createQuery(deleteQuery);
			query.setParameter("isDeleted", testVO.getIsDeleted());
			query.setParameter("modifiedBy", testVO.getModifiedBy());
			query.setParameter("modified", testVO.getModified());
			query.setParameter("id", testVO.getTestId());
			result = query.executeUpdate();
		} catch (HibernateException he) {

			LOGGER.debug(he.getMessage() + he);
		}

		return result;
	}

	@Override
	public List<TestTypeBO> retrieveTestTypeBO() {
		List<TestTypeBO> testTypeList=new ArrayList<TestTypeBO>();
		try {
			/*String hqlQuery = "SELECT testTypeName FROM TestTypeVO WHERE isDeleted=:status";
			Query query = getSession().createQuery(hqlQuery);
			query.setParameter("status", true);*/
			Criteria criteria=getSession().createCriteria(TestTypeVO.class);
			criteria.add(Restrictions.eq("isDeleted", true));
			criteria.addOrder(Order.asc("testTypeName"));
			List<TestTypeVO> categoryList = criteria.list();
			for(TestTypeVO test:categoryList)
			{
				TestTypeBO retrivetest=new TestTypeBO();
				retrivetest.setId(test.getTestTypeId());
				retrivetest.setTestTypeName(test.getTestTypeName());
				//BeanUtils.copyProperties(test, retrivetest);
				testTypeList.add(retrivetest);

			}
			return testTypeList;
		} catch (Exception ex) {
			ex.printStackTrace();
		}
		return null;
	}

	@Override
	public List<TestBO> retriveTestName(TestBO testBO) {

		List<TestBO> testandscanList=new ArrayList<TestBO>();
		List<TestVO> testscanVoList=new ArrayList<TestVO>();
		Criteria criteria=getSession().createCriteria(TestVO.class);
		if(null!=testBO.getTestHead()&&!testBO.getTestHead().isEmpty()){
			criteria.createCriteria("testHeadVO").add(Restrictions.eq("testHead", testBO.getTestHead()));
		}
		if(null!=testBO.getTestTypeName()){
			criteria.createCriteria("testTypeVO").add(Restrictions.eq("testTypeId", testBO.getTestTypeId()));
		}
		criteria.add(Restrictions.eq("isDeleted", true));
		criteria.addOrder(Order.asc("testName"));
		if(null!=criteria.list()&&criteria.list().size()>0)
		{
			testscanVoList=criteria.list();
			for(TestVO test:testscanVoList)
			{
				TestBO retrivetest=new TestBO();
				retrivetest.setId(test.getTestId());
				BeanUtils.copyProperties(test, retrivetest);
				testandscanList.add(retrivetest);

			}
			return testandscanList;
		}
		return null;
	}

	@Override
	public TestVO retriveTestAmount(TestBO testBO) {

		List<TestVO> list=new ArrayList<TestVO>();
		TestVO retriveResult=new TestVO();

		Criteria criteria=getSession().createCriteria(TestVO.class);
		criteria.add(Restrictions.eq("testId", testBO.getId()));

		list=criteria.list();

		for(TestVO result:list)
		{
			retriveResult.setAmount(result.getAmount());
		}
		// TODO Auto-generated method stub
		return retriveResult;
	}

	@Override
	public TemplateBO retriveTemplate(TemplateBO templateBO) {
		// TODO Auto-generated method stub
		TemplateBO checktemplateBO = null;
		List<TemplateBO> list=new ArrayList<TemplateBO>();
		Criteria criteria=getSession().createCriteria(TemplateVO.class);
		if(null!=templateBO.getTemplateName()){
		criteria.add(Restrictions.eq("templateName",templateBO.getTemplateName()));
		}
		
		List<TemplateVO> templateList=criteria.list();
		if(null!=templateList&&templateList.size()>0){
			for(TemplateVO checktemplate:templateList){
				checktemplateBO=new TemplateBO();
				checktemplateBO.setTemplateCode(checktemplate.getTemplateCode());
				checktemplateBO.setTemplateName(checktemplate.getTemplateName());
				list.add(checktemplateBO);
				templateBO.setAllTestBOList(list);
			}
		}
		return checktemplateBO;
	}

	@Override
	public TemplateBO retriveTemplateCode(TemplateBO templateBO) {
		// TODO Auto-generated method stub
		TemplateBO checktemplateBO = null;
		List<TemplateBO> list=new ArrayList<TemplateBO>();
		Criteria criteria=getSession().createCriteria(TemplateVO.class);
		if(null!=templateBO.getTemplateCode()){
			criteria.add(Restrictions.eq("templateCode",templateBO.getTemplateCode()));	
		}		
		List<TemplateVO> templateList=criteria.list();
		if(null!=templateList&&templateList.size()>0){
			for(TemplateVO checktemplate:templateList){
				checktemplateBO=new TemplateBO();
				checktemplateBO.setTemplateCode(checktemplate.getTemplateCode());
				checktemplateBO.setTemplateName(checktemplate.getTemplateName());
				list.add(checktemplateBO);
				templateBO.setAllTestBOList(list);
			}
		}
		return checktemplateBO;		
	}

	@Override
	public long createTemplate(TemplateVO templateVO) {

		long id = 0;
		try {
			id = (long)getSession().save(templateVO);
		} catch (Exception he) {
			LOGGER.debug(he.getMessage() + he);
		}

		return id;
	}

	@Override
	public long findimageLatestSquence(String columnName, String tableName) {
		// TODO Auto-generated method stub


		String value=null;
		long id=0;
		String sqlQuerry="SELECT " + columnName + " FROM " + tableName
				+ " ORDER BY " + columnName + " DESC LIMIT 1";
		SQLQuery querry=getSession().createSQLQuery(sqlQuerry);
		if(querry.list().size()>0)
		{
			value=querry.list().get(0).toString();
			id=Long.parseLong(value);
		}
		// TODO Auto-generated method stub
		return id;
	
	}

}
