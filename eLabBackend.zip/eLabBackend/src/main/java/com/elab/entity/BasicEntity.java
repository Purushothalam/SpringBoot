package com.elab.entity;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.MappedSuperclass;
import javax.persistence.PrePersist;
import javax.persistence.PreUpdate;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;



@MappedSuperclass
public class BasicEntity implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@Column(name = "created_date")
	private Date created = new Date();

	@Column(name = "modified_date")
	private Date modified = new Date();

	@Column(name = "created_by", nullable = false)
	private long createdBy;

	@Column(name = "modified_by", nullable = false)
	private long modifiedBy;

	/**
	 * @return the created
	 */

	
	
	
	@Column(updatable = false)
	@Temporal(TemporalType.TIMESTAMP)
	public Date getCreated() {
		return created;
	}

	/**
	 * @param created
	 *            the created to set
	 */
	public void setCreated(Date created) {
		this.created = created;
	}

	/**
	 * @return the modified
	 */
	
	
	@Temporal(TemporalType.TIMESTAMP)
	public Date getModified() {
		return modified;
	}

	@PrePersist
	@PreUpdate
	protected void updateModifiedDate() {
		modified = new Date();
	}

	/**
	 * @param modified
	 *            the modified to set
	 */
	public void setModified(Date modified) {
		this.modified = modified;
	}

	/**
	 * @return the created_By
	 */
	public long getCreatedBy() {
		return createdBy;
	}

	/**
	 * @param created_By
	 *            the created_By to set
	 */
	public void setCreatedBy(long createdBy) {
		this.createdBy = createdBy;
	}

	/**
	 * @return the modified_By
	 */
	public long getModifiedBy() {
		return modifiedBy;
	}

	/**
	 * @param modified_By
	 *            the modified_By to set
	 */
	public void setModifiedBy(long modifiedBy) {
		this.modifiedBy = modifiedBy;
	}

	/**
	 * 
	 */

}
