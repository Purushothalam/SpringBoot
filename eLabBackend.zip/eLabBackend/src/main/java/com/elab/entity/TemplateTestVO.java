package com.elab.entity;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToOne;
import javax.persistence.Table;



@Entity
@Table(name="template_lab_test")
public class TemplateTestVO {
	
	
	private long tempTestId;
	
	private TemplateVO templatevo;
	
	private TestVO testvo;
	
	private TestTypeVO testTypeVO;

	@Id
	@GeneratedValue
	@Column(name="temp_test_id")
	public long getTempTestId() {
		return tempTestId;
	}

	public void setTempTestId(long tempTestId) {
		this.tempTestId = tempTestId;
	}
    
	@OneToOne(cascade=CascadeType.PERSIST,fetch=FetchType.EAGER)
	@JoinColumn(name="template_lab")
	public TemplateVO getTemplatevo() {
		return templatevo;
	}

	public void setTemplatevo(TemplateVO templatevo) {
		this.templatevo = templatevo;
	}
	
	@ManyToOne
	@JoinColumn(name="test_id")
	public TestVO getTestvo() {
		return testvo;
	}

	public void setTestvo(TestVO testvo) {
		this.testvo = testvo;
	}

	@ManyToOne
	@JoinColumn(name="test_type_id")
	public TestTypeVO getTestTypeVO() {
		return testTypeVO;
	}

	public void setTestTypeVO(TestTypeVO testTypeVO) {
		this.testTypeVO = testTypeVO;
	}
	
	

}
