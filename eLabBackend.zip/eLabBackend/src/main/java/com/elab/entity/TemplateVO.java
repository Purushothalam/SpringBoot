package com.elab.entity;

import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import com.elab.model.TestBO;

@Entity
@Table(name = "template")
public class TemplateVO extends BasicEntity {

	/**
	 * 
	 */
	private static final long serialVersionUID = 5141337393919186437L;

	
	private long tempId;
	
	
	private String templateName;
	
	
	private String templateCode;
	
	private List<TemplateTestVO> templateTest;

	
	@OneToMany(cascade=CascadeType.ALL)
	@JoinColumn(name="template_lab")
	public List<TemplateTestVO> getTemplateTest() {
		return templateTest;
	}


	public void setTemplateTest(List<TemplateTestVO> templateTest) {
		this.templateTest = templateTest;
	}

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "template_id")
	public long getTempId() {
		return tempId;
	}


	public void setTempId(long tempId) {
		this.tempId = tempId;
	}

	@Column(name = "template_name")
	public String getTemplateName() {
		return templateName;
	}


	public void setTemplateName(String templateName) {
		this.templateName = templateName;
	}

	@Column(name = "template_code")
	public String getTemplateCode() {
		return templateCode;
	}


	public void setTemplateCode(String templateCode) {
		this.templateCode = templateCode;
	}


	
	

}
