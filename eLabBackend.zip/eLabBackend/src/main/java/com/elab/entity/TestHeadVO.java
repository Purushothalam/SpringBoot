package com.elab.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;


@Entity
@Table(name = "Test_Head")
public class TestHeadVO extends BasicEntity {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "test_head_id")
	
	private long testHeadId;

	public long getTestHeadId() {
		return testHeadId;
	}

	public void setTestHeadId(long testHeadId) {
		this.testHeadId = testHeadId;
	}

	public String getTestHead() {
		return testHead;
	}

	public void setTestHead(String testHead) {
		this.testHead = testHead;
	}

	public TestTypeVO getTestTypeVO() {
		return testTypeVO;
	}

	public void setTestTypeVO(TestTypeVO testTypeVO) {
		this.testTypeVO = testTypeVO;
	}

	@Column(name = "test_head_name")
	
	private String testHead;

	@Column(name = "is_deleted")
	
	private Boolean isDeleted;

	@JoinColumn(name = "test_type_id")
	@ManyToOne(fetch = FetchType.EAGER)
	private TestTypeVO testTypeVO;

	

	/**
	 * @return the isDeleted
	 */
	public Boolean getIsDeleted() {
		return isDeleted;
	}

	/**
	 * @param isDeleted
	 *            the isDeleted to set
	 */
	public void setIsDeleted(Boolean isDeleted) {
		this.isDeleted = isDeleted;
	}

}
