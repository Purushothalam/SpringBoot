package com.elab.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "test_type")
public class TestTypeVO extends BasicEntity {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "test_type_id")
	private long testTypeId;
	
	@Column(name = "test_Type")
	private String testTypeName;
	
	
	public String getTestTypeName() {
		return testTypeName;
	}


	public void setTestTypeName(String testTypeName) {
		this.testTypeName = testTypeName;
	}


	@Column(name = "is_deleted")
	private Boolean isDeleted;
	
	public long getTestTypeId() {
		return testTypeId;
	}


	public void setTestTypeId(long testTypeId) {
		this.testTypeId = testTypeId;
	}


	public Boolean getIsDeleted() {
		return isDeleted;
	}


	public void setIsDeleted(Boolean isDeleted) {
		this.isDeleted = isDeleted;
	}
}
