package com.elab.entity;

import java.math.BigDecimal;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;



@Entity
@Table(name = "test")
public class TestVO extends BasicEntity {

	/**
	 * 
	 */
	private static final long serialVersionUID = 5141337393919186437L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "test_id")
	private long testId;
	
	@Column(name = "test_name")
	private String testName;
	
	/*@Column(name = "test_type")
	private String testCategory;*/
	
	@Column(name = "is_deleted")
	private Boolean isDeleted;
	
	@Column(name = "units")
	private String units;

	@Column(name="imnage_name")
	private String imageName;
	
	@Column(name="normal_range")
	private String normalRange;

	@Column(name="method")
	private String method;
	
	@Column(name="test_amount")
	private BigDecimal amount;
	
	@JoinColumn(name = "test_type_id")
	@ManyToOne(fetch = FetchType.EAGER)
	private TestTypeVO testTypeVO;

	@JoinColumn(name = "test_head_id")
	@ManyToOne(fetch = FetchType.EAGER)
	private TestHeadVO testHeadVO;
	
	
	@Column(name = "test_description", columnDefinition = "TEXT")
	private String testDescription;

	public String getImageName() {
		return imageName;
	}

	public void setImageName(String imageName) {
		this.imageName = imageName;
	}

	public BigDecimal getAmount() {
		return amount;
	}

	public void setAmount(BigDecimal amount) {
		this.amount = amount;
	}

	public String getTestDescription() {
		return testDescription;
	}

	public void setTestDescription(String testDescription) {
		this.testDescription = testDescription;
	}

	/**
	 * @return the testName
	 */
	public String getTestName() {
		return testName;
	}

	/**
	 * @param testName
	 *            the testName to set
	 */
	public void setTestName(String testName) {
		this.testName = testName;
	}

	/**
	 * @return the testCategory
	 *//*

	public String getTestCategory() {
		return testCategory;
	}

	*//**
	 * @param testCategory
	 *            the testCategory to set
	 *//*
	public void setTestCategory(String testCategory) {
		this.testCategory = testCategory;
	}
*/
	/**
	 * @return the isDeleted
	 */
	public Boolean getIsDeleted() {
		return isDeleted;
	}

	/**
	 * @param isDeleted
	 *            the isDeleted to set
	 */
	public void setIsDeleted(Boolean isDeleted) {
		this.isDeleted = isDeleted;
	}

	/**
	 * @return the testId
	 */
	public long getTestId() {
		return testId;
	}

	/**
	 * @param testId
	 *            the testId to set
	 */
	public void setTestId(long testId) {
		this.testId = testId;
	}
	
	public TestTypeVO getTestTypeVO() {
		return testTypeVO;
	}

	public void setTestTypeVO(TestTypeVO testTypeVO) {
		this.testTypeVO = testTypeVO;
	}

	public TestHeadVO getTestHeadVO() {
		return testHeadVO;
	}

	public void setTestHeadVO(TestHeadVO testHeadVO) {
		this.testHeadVO = testHeadVO;
	}
	
	public String getNormalRange() {
		return normalRange;
	}

	public void setNormalRange(String normalRange) {
		this.normalRange = normalRange;
	}

	public String getMethod() {
		return method;
	}

	public void setMethod(String method) {
		this.method = method;
	}
	
	public String getUnits() {
		return units;
	}

	public void setUnits(String units) {
		this.units = units;
	}

}
