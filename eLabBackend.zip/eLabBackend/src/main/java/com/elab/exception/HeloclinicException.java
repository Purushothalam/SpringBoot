
package com.elab.exception;

public class HeloclinicException	
    extends java.lang.Exception
{
   
	private static final long serialVersionUID = 1L;

	
    private String key;
    private Object[] parameters;
    private String errorCode;
    private String errorMessage;  
    
    /**
     * Constructs an instance of <code>HeloclinicException</code> with the
     * specified detail message.
     * 
     * @param msg the detail message.
     * @param resourcekey the key to load the translated resource
     * @param parameters the array of objects, which are formatted into
     *            the translated message, resolved from the resource
     *            key; the array can be null, if no parameters are used
     */
    public HeloclinicException(String msg, String resourcekey, Object[] parameters)
    {
        super(msg);
        this.key = resourcekey;
        this.parameters = parameters;
    }
    /**
     * 
     * @param ErrorCode
     * @param ErrorMessage
     */
    
    public HeloclinicException(String errorCode,String errorMessage)
    {
    	
    	this.errorCode=errorCode;
    	this.errorMessage=errorMessage;
    }
    
    
    

    /**
     * Constructs an instance of <code>HeloclinicException</code> with the
     * specified original exception.
     * 
     * @param t the original exception.
     * @param resourcekey the key to load the translated resource
     * @param parameters the array of objects, which are formatted into
     *            the translated message, resolved from the resource
     *            key; the array can be null, if no parameters are used
     */
    public HeloclinicException(Throwable t, String resourcekey, Object[] parameters)
    {
        super(t);
        this.key = resourcekey;
        this.parameters = parameters;
    }

    /**
     * Constructs an instance of <code>HeloclinicException</code> with the
     * specified detail message.
     * 
     * @param msg the detail message.
     * @param resourcekey the key to load the translated resource
     * @param parameters the array of objects, which are formatted into
     *            the translated message, resolved from the resource
     *            key; the array can be null, if no parameters are used
     * @param bundleName
     */
    public HeloclinicException(
        String msg,
        String resourcekey,
        Object[] parameters,
        String bundleName)
    {
        super(msg);
        this.key = resourcekey;
        this.parameters = parameters;
     
    }

    /**
     * Constructs an instance of <code>HeloclinicException</code> with the
     * specified original exception.
     * 
     * @param t the original exception.
     * @param resourcekey the key to load the translated resource
     * @param parameters the array of objects, which are formatted into
     *            the translated message, resolved from the resource
     *            key; the array can be null, if no parameters are used
     * @param bundleName
     */
    public HeloclinicException(
        Throwable t,
        String resourcekey,
        Object[] parameters,
        String bundleName)
    {
        super(t);
        this.key = resourcekey;
        this.parameters = parameters;
        
    } 

	public HeloclinicException(String message) {
		this.errorMessage=message;
	}	
	

    public String getKey() {
        return key;
    }

    public Object[] getParameters() {
        return parameters;
    }     

	public String getErrorCode() {
		return errorCode;
	}
	public void setErrorCode(String errorCode) {
		this.errorCode = errorCode;
	}
	public String getErrorMessage() {
		return errorMessage;
	}
	public void setErrorMessage(String errorMessage) {
		this.errorMessage = errorMessage;
	}
	
	
	
	
	
}
