package com.elab.model;

import java.util.List;

import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;

import org.hibernate.validator.constraints.Email;
import org.hibernate.validator.constraints.NotEmpty;

public class AdminLoginBO extends BaseBO {

	/**
	 * 
	 */
	private static final long serialVersionUID = -5075544932678455420L;
	@NotEmpty(message="User Email may not be empty")
	@Email
	@Pattern(regexp = ".+@.+\\.[a-z]+", message = "Email is not correct format")
	private String emailAddress;
	@NotEmpty(message="Password may not be empty")
	@Size(min = 3, max = 8)
	private String password;

	private List<AdminLoginBO> allProfileList;

	private List<AdminLoginBO> adminUserList;
    private String userType;
    
    private String createDate;
    
    private String modifiedDate;
    private boolean rememberMe;
	/**
	 * @return the emailAddress
	 */
	public String getEmailAddress() {
		return emailAddress;
	}

	/**
	 * @param emailAddress
	 *            the emailAddress to set
	 */
	public void setEmailAddress(String emailAddress) {
		this.emailAddress = emailAddress;
	}

	/**
	 * @return the password
	 */
	public String getPassword() {
		return password;
	}

	/**
	 * @param password
	 *            the password to set
	 */
	public void setPassword(String password) {
		this.password = password;
	}

	/**
	 * @return the allProfileList
	 */
	public List<AdminLoginBO> getAllProfileList() {
		return allProfileList;
	}

	/**
	 * @param allProfileList
	 *            the allProfileList to set
	 */
	public void setAllProfileList(List<AdminLoginBO> allProfileList) {
		this.allProfileList = allProfileList;
	}

	/**
	 * @return the adminUserList
	 */
	public List<AdminLoginBO> getAdminUserList() {
		return adminUserList;
	}

	/**
	 * @param adminUserList
	 *            the adminUserList to set
	 */
	public void setAdminUserList(List<AdminLoginBO> adminUserList) {
		this.adminUserList = adminUserList;
	}

	/**
	 * @return the userType
	 */
	public String getUserType() {
		return userType;
	}

	/**
	 * @param userType the userType to set
	 */
	public void setUserType(String userType) {
		this.userType = userType;
	}

	/**
	 * @return the createDate
	 */
	public String getCreateDate() {
		return createDate;
	}

	/**
	 * @param createDate the createDate to set
	 */
	public void setCreateDate(String createDate) {
		this.createDate = createDate;
	}

	/**
	 * @return the modifiedDate
	 */
	public String getModifiedDate() {
		return modifiedDate;
	}

	/**
	 * @param modifiedDate the modifiedDate to set
	 */
	public void setModifiedDate(String modifiedDate) {
		this.modifiedDate = modifiedDate;
	}

	public boolean getRememberMe() {
		return rememberMe;
	}

	public void setRememberMe(boolean rememberMe) {
		this.rememberMe = rememberMe;
	}

}
