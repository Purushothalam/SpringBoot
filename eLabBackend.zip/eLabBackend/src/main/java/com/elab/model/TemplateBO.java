package com.elab.model;

import java.math.BigDecimal;
import java.util.List;

import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;

import org.hibernate.validator.constraints.NotEmpty;
import org.hibernate.validator.constraints.Range;
import org.springframework.web.multipart.commons.CommonsMultipartFile;

import com.mysql.jdbc.Blob;

public class TemplateBO extends BaseBO {

	/**
	 * 
	 */
	private static final long serialVersionUID = 6027820303278822380L;

	@NotEmpty(message="TestName cannot be empty")
	@Size(min = 3, max = 40)
	@Pattern(regexp = "^[a-zA-Z\\s]*$", message = "Test Name Should be a Character only")
	private String templateName;

	private String templateCode;
	
	private String testName;

	private List<TemplateBO> allTestBOList;
	
	private String searchElement;
	
	private long testTypeId;

	private String testHead;
	
	private String testTypeName;
	
	private long testHeadId;
	
	private BigDecimal amount;
	
	private String createdate;
	
	private String modifiedDate;

	private List<TestBO> TestList;

	private long templateId;
	
	public long getTemplateId() {
		return templateId;
	}

	public void setTemplateId(long templateId) {
		this.templateId = templateId;
	}

	/**
	 * @return the testName
	 */
	public String getTestName() {
		return testName;
	}

	/**
	 * @param testName
	 *            the testName to set
	 */
	public void setTestName(String testName) {
		this.testName = testName;
	}

	
	/**
	 * @return the allTestBOList
	 */
	public List<TemplateBO> getAllTestBOList() {
		return allTestBOList;
	}

	/**
	 * @param allTestBOList
	 *            the allTestBOList to set
	 */
	public void setAllTestBOList(List<TemplateBO> allTestBOList) {
		this.allTestBOList = allTestBOList;
	}

	/**
	 * @return the searchElement
	 */
	public String getSearchElement() {
		return searchElement;
	}

	/**
	 * @param searchElement the searchElement to set
	 */
	public void setSearchElement(String searchElement) {
		this.searchElement = searchElement;
	}

	/**
	 * @return the createdate
	 */
	public String getCreatedate() {
		return createdate;
	}

	/**
	 * @param createdate the createdate to set
	 */
	public void setCreatedate(String createdate) {
		this.createdate = createdate;
	}

	/**
	 * @return the modifiedDate
	 */
	public String getModifiedDate() {
		return modifiedDate;
	}

	/**
	 * @param modifiedDate the modifiedDate to set
	 */
	public void setModifiedDate(String modifiedDate) {
		this.modifiedDate = modifiedDate;
	}

	public long getTestTypeId() {
		return testTypeId;
	}

	public void setTestTypeId(long testTypeId) {
		this.testTypeId = testTypeId;
	}

	public String getTestHead() {
		return testHead;
	}

	public void setTestHead(String testHead) {
		this.testHead = testHead;
	}

	public String getTestTypeName() {
		return testTypeName;
	}

	public void setTestTypeName(String testTypeName) {
		this.testTypeName = testTypeName;
	}

	public long getTestHeadId() {
		return testHeadId;
	}

	public void setTestHeadId(long testHeadId) {
		this.testHeadId = testHeadId;
	}
	
	public String getTemplateName() {
		return templateName;
	}

	public void setTemplateName(String templateName) {
		this.templateName = templateName;
	}

	public String getTemplateCode() {
		return templateCode;
	}

	public void setTemplateCode(String templateCode) {
		this.templateCode = templateCode;
	}

	public BigDecimal getAmount() {
		return amount;
	}

	public void setAmount(BigDecimal amount) {
		this.amount = amount;
	}

	public List<TestBO> getTestList() {
		return TestList;
	}

	public void setTestList(List<TestBO> testList) {
		TestList = testList;
	}
	
}
