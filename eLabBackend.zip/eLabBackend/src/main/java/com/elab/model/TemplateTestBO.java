package com.elab.model;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToOne;
import javax.persistence.Table;




public class TemplateTestBO {
	
	
	private long tempTestId;
	
	private TemplateBO templateBO;
	
	private TestBO testBO;
	
	public TemplateBO getTemplateBO() {
		return templateBO;
	}

	public void setTemplateBO(TemplateBO templateBO) {
		this.templateBO = templateBO;
	}

	public TestBO getTestBO() {
		return testBO;
	}

	public void setTestBO(TestBO testBO) {
		this.testBO = testBO;
	}

	public TestTypeBO getTestTypeBO() {
		return testTypeBO;
	}

	public void setTestTypeBO(TestTypeBO testTypeBO) {
		this.testTypeBO = testTypeBO;
	}

	private TestTypeBO testTypeBO;

	
	public long getTempTestId() {
		return tempTestId;
	}

	public void setTempTestId(long tempTestId) {
		this.tempTestId = tempTestId;
	}

	

	
	

}
