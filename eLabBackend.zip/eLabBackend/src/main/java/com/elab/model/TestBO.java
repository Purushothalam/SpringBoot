package com.elab.model;

import java.math.BigDecimal;
import java.util.List;

import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;

import org.hibernate.validator.constraints.NotEmpty;
import org.hibernate.validator.constraints.Range;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.multipart.commons.CommonsMultipartFile;

import com.mysql.jdbc.Blob;

public class TestBO extends BaseBO {

	/**
	 * 
	 */
	private static final long serialVersionUID = 6027820303278822380L;

	@NotEmpty(message="TestName cannot be empty")
	@Size(min = 3, max = 40)
	@Pattern(regexp = "^[a-zA-Z\\s]*$", message = "Test Name Should be a Character only")
	private String testName;

	/*@NotEmpty*/
   /* private String testCategory;*/

	private List<TestBO> allTestBOList;
	
	private String searchElement;
	
	private long testTypeId;

	private String testHead;
	
	private String testTypeName;
	
	private long testHeadId;
	
	private String createdate;
	
	private String modifiedDate;
	
	private Blob profileImage;
	
	private String imagePath;
	
	private String imageName;
	
	private String normalRange;
	
	private String units;

	private String method;
	
	private CommonsMultipartFile commonsMultipartFile;
	private MultipartFile image;
	private BigDecimal amount;
	
	@NotEmpty
	private String testDescription;
	

	/**
	 * @return the testName
	 */
	public String getTestName() {
		return testName;
	}

	/**
	 * @param testName
	 *            the testName to set
	 */
	public void setTestName(String testName) {
		this.testName = testName;
	}

	/**
	 * @return the testCategory
	 *//*
	public String getTestCategory() {
		return testCategory;
	}

	*//**
	 * @param testCategory
	 *            the testCategory to set
	 *//*
	public void setTestCategory(String testCategory) {
		this.testCategory = testCategory;
	}
*/
	/**
	 * @return the allTestBOList
	 */
	public List<TestBO> getAllTestBOList() {
		return allTestBOList;
	}

	/**
	 * @param allTestBOList
	 *            the allTestBOList to set
	 */
	public void setAllTestBOList(List<TestBO> allTestBOList) {
		this.allTestBOList = allTestBOList;
	}

	/**
	 * @return the searchElement
	 */
	public String getSearchElement() {
		return searchElement;
	}

	/**
	 * @param searchElement the searchElement to set
	 */
	public void setSearchElement(String searchElement) {
		this.searchElement = searchElement;
	}

	/**
	 * @return the createdate
	 */
	public String getCreatedate() {
		return createdate;
	}

	/**
	 * @param createdate the createdate to set
	 */
	public void setCreatedate(String createdate) {
		this.createdate = createdate;
	}

	/**
	 * @return the modifiedDate
	 */
	public String getModifiedDate() {
		return modifiedDate;
	}

	/**
	 * @param modifiedDate the modifiedDate to set
	 */
	public void setModifiedDate(String modifiedDate) {
		this.modifiedDate = modifiedDate;
	}

	public Blob getProfileImage() {
		return profileImage;
	}

	public void setProfileImage(Blob profileImage) {
		this.profileImage = profileImage;
	}

	public String getImagePath() {
		return imagePath;
	}

	public void setImagePath(String imagePath) {
		this.imagePath = imagePath;
	}

	public String getImageName() {
		return imageName;
	}

	public void setImageName(String imageName) {
		this.imageName = imageName;
	}

	public CommonsMultipartFile getCommonsMultipartFile() {
		return commonsMultipartFile;
	}

	public void setCommonsMultipartFile(CommonsMultipartFile commonsMultipartFile) {
		this.commonsMultipartFile = commonsMultipartFile;
	}

	public BigDecimal getAmount() {
		return amount;
	}

	public void setAmount(BigDecimal amount) {
		this.amount = amount;
	}

	public String getTestDescription() {
		return testDescription;
	}

	public void setTestDescription(String testDescription) {
		this.testDescription = testDescription;
	}

	public long getTestTypeId() {
		return testTypeId;
	}

	public void setTestTypeId(long testTypeId) {
		this.testTypeId = testTypeId;
	}

	public String getTestHead() {
		return testHead;
	}

	public void setTestHead(String testHead) {
		this.testHead = testHead;
	}

	public String getTestTypeName() {
		return testTypeName;
	}

	public void setTestTypeName(String testTypeName) {
		this.testTypeName = testTypeName;
	}

	public long getTestHeadId() {
		return testHeadId;
	}

	public void setTestHeadId(long testHeadId) {
		this.testHeadId = testHeadId;
	}
	
	public String getNormalRange() {
		return normalRange;
	}

	public void setNormalRange(String normalRange) {
		this.normalRange = normalRange;
	}

	public String getMethod() {
		return method;
	}

	public void setMethod(String method) {
		this.method = method;
	}

	public String getUnits() {
		return units;
	}

	public void setUnits(String units) {
		this.units = units;
	}

	public MultipartFile getImage() {
		return image;
	}

	public void setImage(MultipartFile image) {
		this.image = image;
	}
	
}
