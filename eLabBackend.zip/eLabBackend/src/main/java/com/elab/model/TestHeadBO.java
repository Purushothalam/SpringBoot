package com.elab.model;

import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;

import org.hibernate.validator.constraints.NotEmpty;

public class TestHeadBO extends BaseBO {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@NotEmpty
	private String testType;

	private long testTypeId;

	@NotEmpty(message = "Title may not be empty")
	@Pattern(regexp = "^[a-zA-Z0-9-\\.\\s]*$", message = "Enter The Title Name in valid format")
	@Size(min = 3, max = 50)
	private String testHead;

	private Boolean isDeleted;
	
	
	private String searchElement;
	
	private String createdDate;
	
	private int sNo;
	
	/**
	 * @return the sNo
	 */
	public int getsNo() {
		return sNo;
	}

	/**
	 * @param sNo the sNo to set
	 */
	public void setsNo(int sNo) {
		this.sNo = sNo;
	}

	/**
	 * @return the isDeleted
	 */
	public Boolean getIsDeleted() {
		return isDeleted;
	}

	/**
	 * @param isDeleted
	 *            the isDeleted to set
	 */
	public void setIsDeleted(Boolean isDeleted) {
		this.isDeleted = isDeleted;
	}

	/**
	 * @return the searchElement
	 */
	public String getSearchElement() {
		return searchElement;
	}

	/**
	 * @param searchElement the searchElement to set
	 */
	public void setSearchElement(String searchElement) {
		this.searchElement = searchElement;
	}

	/**
	 * @return the createdDate
	 */
	public String getCreatedDate() {
		return createdDate;
	}

	/**
	 * @param createdDate the createdDate to set
	 */
	public void setCreatedDate(String createdDate) {
		this.createdDate = createdDate;
	}
	
	public String getTestType() {
		return testType;
	}

	public void setTestType(String testType) {
		this.testType = testType;
	}

	public long getTestTypeId() {
		return testTypeId;
	}

	public void setTestTypeId(long testTypeId) {
		this.testTypeId = testTypeId;
	}

	public String getTestHead() {
		return testHead;
	}

	public void setTestHead(String testHead) {
		this.testHead = testHead;
	}

}
