package com.elab.model;

public class TestTypeBO extends BaseBO{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	private long testTypeId;
	
	public long getTestTypeId() {
		return testTypeId;
	}

	public void setTestTypeId(long testTypeId) {
		this.testTypeId = testTypeId;
	}

	private String testTypeName;
	
	private String searchElement;

	public String getTestTypeName() {
		return testTypeName;
	}

	public void setTestTypeName(String testTypeName) {
		this.testTypeName = testTypeName;
	}

	public String getSearchElement() {
		return searchElement;
	}

	public void setSearchElement(String searchElement) {
		this.searchElement = searchElement;
	}	
	 
}
