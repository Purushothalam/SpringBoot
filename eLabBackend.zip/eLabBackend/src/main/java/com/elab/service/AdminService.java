package com.elab.service;

import com.elab.exception.HeloclinicException;
import com.elab.model.AdminLoginBO;

public interface AdminService {

	AdminLoginBO authenticate(AdminLoginBO adminLoginBO);

	AdminLoginBO retrieveProfile(AdminLoginBO loginBO);

	boolean addAdminUser(AdminLoginBO loginBO) throws HeloclinicException;

	boolean changePassword(AdminLoginBO loginBO);

	AdminLoginBO retrieveAdminUsers(AdminLoginBO loginBO);

	boolean editAdminUser(AdminLoginBO loginBO);

	AdminLoginBO deleteAdminUser(AdminLoginBO adminLoginBO);

}
