package com.elab.service;

import java.util.ArrayList;
import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.elab.dao.AdminDao;
import com.elab.exception.HeloclinicException;
import com.elab.model.AdminLoginBO;
import com.elab.utils.ErrorCodes;
import com.elab.utils.SuccessMsg;
import com.elab.entity.AdminLoginVO;

@Service
@Transactional
public class AdminServiceImpl implements AdminService {
@Autowired
AdminDao adminDao;
	@Override
	public AdminLoginBO authenticate(AdminLoginBO adminLoginBO) {

		AdminLoginBO loginBO = new AdminLoginBO();
		try {
			loginBO = adminDao.authenticate(adminLoginBO);

			if (loginBO.getStatus()) {
				String userName = adminLoginBO.getEmailAddress();
				//addLoginStatus(userName);
				//loginBO.setResponse(SuccessMsg.PT_ACC_ACTIVATION);
			}
		} catch (Exception he) {
			
		}

		return loginBO;
	}
	@Override
	public AdminLoginBO retrieveProfile(AdminLoginBO loginBO) {

	//	List<AdminLoginBO> adminLoginBOList = new ArrayList<AdminLoginBO>();
		try {
			AdminLoginBO adminLogin = adminDao.retrieveProfile(loginBO);
			if ( null!=adminLogin) {
				return adminLogin;
				//loginBO.setAllProfileList(adminLoginBOList);
			}
		} catch (Exception he) {
			//loginBO.setErrorCode(he.getErrorCode());
			//loginBO.setErrorMessage(he.getErrorMessage());
			//LOGGER.debug(ErrorCodes.PT_LOG_FAIL + he);
		}

		return loginBO;
	}
	@Override
	public boolean addAdminUser(AdminLoginBO loginBO)
			  {

		boolean isStatus = false;
		try {
			AdminLoginVO loginVO = new AdminLoginVO();
			BeanUtils.copyProperties(loginBO, loginVO);
			loginVO.setUserType("Admin");
			long id = adminDao.addAdminUser(loginVO);
			if (0 != id) {
				isStatus = true;
			}
		} catch (Exception he) {
			//LOGGER.debug(he.getMessage() + he);
		}

		return isStatus;
	}
	@Override
	public boolean changePassword(AdminLoginBO adminLoginBO) {

		boolean passwordChange = false;
		AdminLoginVO adminLoginVO = new AdminLoginVO();
		try {
			if (null != adminLoginBO.getEmailAddress()
					&& null != adminLoginBO.getPassword()) {

				BeanUtils.copyProperties(adminLoginBO, adminLoginVO);

				adminLoginVO = adminDao.changePassword(adminLoginVO);
				if (null != adminLoginVO.getPassword()
						&& null != adminLoginVO.getEmailAddress()) {
					passwordChange = true;
				}
			}

		} catch (Exception he) {

		}

		return passwordChange;
	}
	@Override
	public AdminLoginBO retrieveAdminUsers(AdminLoginBO loginBO) {

		List<AdminLoginBO> adminUserBOList = new ArrayList<AdminLoginBO>();
		try {
			adminUserBOList = adminDao.retrieveAdminUsers(loginBO);
			if (adminUserBOList != null && adminUserBOList.size() > 0) {
				loginBO.setAdminUserList(adminUserBOList);
			}
		} catch (Exception he) {
			//loginBO.setErrorCode(he.getErrorCode());
			//loginBO.setErrorMessage(he.getErrorMessage());
			//LOGGER.debug(ErrorCodes.PT_LOG_FAIL + he);
		}

		return loginBO;
	}
	@Override
	public boolean editAdminUser(AdminLoginBO loginBO) {

		boolean isStatus = false;
		try{
			AdminLoginVO loginVO =adminDao.getadminUser(loginBO.getId());
			loginVO.setPassword(loginBO.getPassword());
			loginBO = adminDao.editAdminUser(loginVO);
			if (null != loginBO.getResponse()) {
				isStatus = true;
			}
		}
		 catch (Exception he) {
			//LOGGER.debug(he.getMessage() + he);
		}

		return isStatus;
	}
	@Override
	public AdminLoginBO deleteAdminUser(AdminLoginBO loginBO) {
		AdminLoginVO loginVO = new AdminLoginVO();
		try {
			loginVO.setId(loginBO.getId());
			loginVO.setIsDeleted(loginBO.getIsDeleted());
			loginVO.setModified(loginBO.getModified());
			loginVO.setModifiedBy(loginBO.getModifiedBy());
			int result = adminDao.deleteAdminUser(loginVO);
			if (result != 0) {
				loginBO.setResponse(SuccessMsg.DELETE_SUCCESS);
			}
		} catch (Exception he) {
		//	loginBO.setErrorCode(he.getErrorCode());
			//loginBO.setErrorMessage(he.getErrorMessage());
			//LOGGER.debug(ErrorCodes.PT_LOG_FAIL + he);
		}

		return loginBO;
	}

}
