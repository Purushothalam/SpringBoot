package com.elab.service;

import java.io.IOException;
import java.util.List;

import com.elab.exception.HeloclinicException;
import com.elab.model.TemplateBO;
import com.elab.model.TestBO;
import com.elab.model.TestHeadBO;
import com.elab.model.TestTypeBO;

public interface LabService {

	long getTestTypeCount(TestTypeBO testTypeBO);

	boolean findTestType(String testTypeName) throws HeloclinicException;

	boolean createTestType(TestTypeBO testTypeBO);

	List<TestTypeBO> retrieveTestType(TestTypeBO testTypeBO);

	TestTypeBO getTestType(long id);

	boolean editTestType(TestTypeBO testTypeBO);

	TestTypeBO deleteTestType(TestTypeBO testTypeBO);

	boolean findTestHeadName(TestHeadBO testHeadBO) throws HeloclinicException;

	long getTestHeadCount(TestHeadBO testHeadBO);

	List<TestHeadBO> retrieveTestHead(TestHeadBO testHeadBO);

	List<String> retrieveTestTypeNameList();

	boolean createTestHead(TestHeadBO testHeadBO);

	TestTypeBO getTestTypeByName(String testTypeName);

	boolean editTestHead(TestHeadBO testHeadBO);

	TestHeadBO getTestHeadById(long id);

	TestHeadBO deleteTestHead(TestHeadBO blogTitleBO);

	List<String> retrieveTestHeadName(TestHeadBO testHeadBO);

	TestBO retrieveTests(TestBO testBO);

	long totalTestCount(TestBO testBO);

	boolean findTest(String testName);

	boolean addTest(TestBO testBO);

	List<TestBO> adminRetrieveTests(TestBO testBO);

	TestHeadBO getTestHeadByName(String testHeadName);

	boolean editTest(TestBO testBO) throws RuntimeException, IOException;

	TestBO deleteTest(TestBO testBO);

	List<TestTypeBO> retrieveTestTypeBO();

	List<TestBO> retriveTestName(TestBO testBO);

	TestBO retriveTestAmount(TestBO testBO);

	boolean retriveTemplate(TemplateBO templateBO);

	boolean retriveTemplateCode(TemplateBO templateBO);

	Boolean createTemplate(TemplateBO templateBO);

	long imagelatestSequence(String string, String string2);

}
