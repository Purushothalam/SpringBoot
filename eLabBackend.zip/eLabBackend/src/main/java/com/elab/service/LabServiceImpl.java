package com.elab.service;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.transaction.Transactional;

import org.apache.log4j.Logger;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.elab.dao.LabDao;
import com.elab.model.TemplateBO;
import com.elab.model.TestBO;
import com.elab.model.TestHeadBO;
import com.elab.model.TestTypeBO;
import com.elab.utils.ErrorCodes;
import com.elab.utils.HelloClinicResourceBundle;
import com.elab.utils.SaveImagesToFolder;
import com.elab.utils.SuccessMsg;
import com.elab.entity.TemplateTestVO;
import com.elab.entity.TemplateVO;
import com.elab.entity.TestVO;
import com.elab.entity.TestHeadVO;
import com.elab.entity.TestTypeVO;
import com.elab.exception.HeloclinicException;
@Service
@Transactional
public class LabServiceImpl implements LabService{
	private static final Logger LOGGER = Logger.getLogger(LabServiceImpl.class);
@Autowired
LabDao labDao;
	@Override
	public long getTestTypeCount(TestTypeBO testTypeBO) {
		// TODO Auto-generated method stub
		return labDao.getTestTypeCount(testTypeBO);
	}

	@Override
	public boolean findTestType(String testTypeName) throws HeloclinicException {
		// TODO Auto-generated method stub
		if (null != testTypeName) {
			TestTypeVO testTypeVO = labDao.findTestType(testTypeName);
			if (null != testTypeVO) {
				return true;
			}
		}
		return false;
	}

	@Override
	public boolean createTestType(TestTypeBO testTypeBO) {
		// TODO Auto-generated method stub
		boolean isStatus = false;
		TestTypeVO testTypeVO = new TestTypeVO();
		BeanUtils.copyProperties(testTypeBO, testTypeVO);
		long id = labDao.createTestType(testTypeVO);
		if (0 != id) {
			isStatus = true;
		}

		return isStatus;
	}

	@Override
	public List<TestTypeBO> retrieveTestType(TestTypeBO testTypeBO) {
		// TODO Auto-generated method stub
		return labDao.retrieveTestType(testTypeBO);
	}

	@Override
	public TestTypeBO getTestType(long id) {
		// TODO Auto-generated method stub
		TestTypeBO testTypeBO = new TestTypeBO();
		TestTypeVO testTypeVO = labDao.getTestType(id);
		if (null != testTypeVO) {
			BeanUtils
					.copyProperties(testTypeVO, testTypeBO);

		}
		return testTypeBO;

	}

	@Override
	public boolean editTestType(TestTypeBO testTypeBO) {

		boolean isStatus = false;
		TestTypeVO testTypeVO = new TestTypeVO();
		testTypeVO=labDao.getTestType(testTypeBO.getTestTypeId());
		//BeanUtils.copyProperties(testTypeBO, testTypeVO);
		//testTypeVO.setTestTypeId(testTypeBO.getId());
		testTypeVO.setTestTypeName(testTypeBO.getTestTypeName());
		testTypeVO.setModified(new Date());
		testTypeVO.setModifiedBy(testTypeBO.getModifiedBy());
		testTypeBO = labDao.editTestType(testTypeVO);
		if (null == testTypeBO.getErrorCode()) {
			isStatus = true;
		}

		return isStatus;
	}

	@Override
	public TestTypeBO deleteTestType(TestTypeBO testTypeBO) {

		try {

			int result = labDao.deleteTestType(testTypeBO);
			if (result != 0) {
				testTypeBO.setResponse(SuccessMsg.DELETE_SUCCESS);
			}
		} catch (Exception he) {
			//testTypeBO.setErrorCode(he.getErrorCode());
		//	testTypeBO.setErrorMessage(he.getErrorMessage());
			LOGGER.debug(ErrorCodes.PT_LOG_FAIL + he);
		}

		return testTypeBO;
	}

	@Override
	public boolean findTestHeadName(TestHeadBO testHeadBO) throws HeloclinicException {
		if (null != testHeadBO) {
			TestHeadVO blogTiltle = labDao.findTestHeadName(testHeadBO);
			if (null != blogTiltle) {
				return true;
			}
		}
		return false;
	}

	@Override
	public long getTestHeadCount(TestHeadBO testHeadBO) {
		// TODO Auto-generated method stub
		return labDao.getTestHeadCount(testHeadBO);
	}

	@Override
	public List<TestHeadBO> retrieveTestHead(TestHeadBO testHeadBO) {
		// TODO Auto-generated method stub
		return labDao.retrieveTestHead(testHeadBO);
	}

	@Override
	public List<String> retrieveTestTypeNameList() {
		// TODO Auto-generated method stub
		return labDao.retrieveTestTypeNameList();
	}

	@Override
	public boolean createTestHead(TestHeadBO testHeadBO) {
		// TODO Auto-generated method stub


		boolean isStatus = false;
		TestTypeVO testTypeVO = new TestTypeVO();
		TestHeadVO testHeadVO = new TestHeadVO();
		BeanUtils.copyProperties(testHeadBO, testHeadVO);
		testTypeVO.setTestTypeId(testHeadBO.getTestTypeId());
		testHeadVO.setTestTypeVO(testTypeVO);
		long id = labDao.createTestHead(testHeadVO);
		if (0 != id) {
			isStatus = true;
		}

		return isStatus;
	
	}

	@Override
	public TestTypeBO getTestTypeByName(String testTypeName) {
		return labDao.getTestTypeByName(testTypeName);
		}

	@Override
	public boolean editTestHead(TestHeadBO testHeadBO) {

		boolean isStatus = false;

		TestHeadVO testHeadVO = labDao.getTestHeadById(testHeadBO.getId());
		testHeadVO.setTestHeadId(testHeadBO.getId());
		testHeadVO.getTestTypeVO().setTestTypeId(testHeadBO.getTestTypeId());
		testHeadVO.setTestHead(testHeadBO.getTestHead());
		testHeadBO = labDao.editTestHead(testHeadVO);
		if (null == testHeadBO.getErrorCode()) {
			isStatus = true;
		}

		return isStatus;
	}

	@Override
	public TestHeadBO getTestHeadById(long id) {
		// TODO Auto-generated method stub
		TestHeadBO testHeadBO = new TestHeadBO();
		TestHeadVO testHeadVO = labDao.getTestHeadById(id);
		if (null != testHeadVO) {
			BeanUtils.copyProperties(testHeadVO, testHeadBO);
			testHeadBO.setTestTypeId(testHeadVO.getTestTypeVO().getTestTypeId());
			testHeadBO.setTestType(testHeadVO.getTestTypeVO().getTestTypeName());
		}
		return testHeadBO;
	}

	@Override
	public TestHeadBO deleteTestHead(TestHeadBO testHeadBO) {

		try {

			int result = labDao.deleteTestHead(testHeadBO);
			if (result != 0) {
				testHeadBO.setResponse(SuccessMsg.DELETE_SUCCESS);
			}
		} catch (Exception he) {
			//testHeadBO.setErrorCode(he.getErrorCode());
			//testHeadBO.setErrorMessage(he.getErrorMessage());
			LOGGER.debug(ErrorCodes.PT_LOG_FAIL + he);
		}

		return testHeadBO;
	}

	@Override
	public List<String> retrieveTestHeadName(TestHeadBO testHeadBO) {
		// TODO Auto-generated method stub
		return labDao.retrieveTestHeadName(testHeadBO);
	}

	@Override
	public TestBO retrieveTests(TestBO testBO) {
		// TODO Auto-generated method stub


		List<TestBO> testBOList = new ArrayList<TestBO>();
		try {
			testBOList = labDao.retrieveTests(testBO);
			if (testBOList.size() != 0) {
				testBO.setAllTestBOList(testBOList);
			}
		} catch (Exception he) {
			
			LOGGER.debug(ErrorCodes.PT_LOG_FAIL + he);
		}

		return testBO;
	
	}

	@Override
	public long totalTestCount(TestBO testBO) {
		// TODO Auto-generated method stub
		return labDao.totalTestCount(testBO);
	}

	@Override
	public boolean findTest(String testName) {
		// TODO Auto-generated method stub
		try {
			TestVO test = labDao.findTest(testName);
			if (null != test) {
				return true;
			}
		} catch (Exception he) {
			LOGGER.debug(he.getMessage() + he);
		}
		return false;
	}

	@Override
	public boolean addTest(TestBO testBO) {
		// TODO Auto-generated method stub


		boolean isStatus = false;
		try {
			TestVO testVO = new TestVO();
			TestHeadVO testHeadVO=new TestHeadVO();
			TestTypeVO testTypeVO=new TestTypeVO();
			testHeadVO.setTestHeadId(testBO.getTestHeadId());
			testTypeVO.setTestTypeId(testBO.getTestTypeId());
			testVO.setTestHeadVO(testHeadVO);
			testVO.setTestTypeVO(testTypeVO);
			BeanUtils.copyProperties(testBO, testVO);
			long id = labDao.addTest(testVO);
			if (0 != id) {
				isStatus = true;
			}
		} catch (Exception he) {
			LOGGER.debug(he.getMessage() + he);
			he.printStackTrace();
		}

		return isStatus;
	
	}

	@Override
	public List<TestBO> adminRetrieveTests(TestBO testBO) {
		// TODO Auto-generated method stub
		return labDao.adminRetrieveTests(testBO);
	}

	@Override
	public TestHeadBO getTestHeadByName(String testHeadName) {
		// TODO Auto-generated method stub
		return labDao.getTestHeadByName(testHeadName);
	}

	@Override
	public boolean editTest(TestBO testBO) throws RuntimeException, IOException {
		// TODO Auto-generated method stub


		boolean isStatus = false;
		try {

			SaveImagesToFolder saveImages = new SaveImagesToFolder();
			TestVO testVO = labDao.getTest(testBO.getId());
			/*testVO.setTestCategory(testBO.getTestCategory());*/
			TestTypeVO testTypeVO= new TestTypeVO();
			TestHeadVO testHeadVO = new TestHeadVO();
			testTypeVO.setTestTypeName(testBO.getTestTypeName());
			testTypeVO.setTestTypeId(testBO.getTestTypeId());
			testHeadVO.setTestHead(testBO.getTestHead());
			testHeadVO.setTestHeadId(testBO.getTestHeadId());
			testVO.setTestTypeVO(testTypeVO);
			testVO.setTestHeadVO(testHeadVO);
			testVO.setTestName(testBO.getTestName());
			testVO.setNormalRange(testBO.getNormalRange());
			testVO.setMethod(testBO.getNormalRange());
			testVO.setUnits(testBO.getUnits());
			testVO.setAmount(testBO.getAmount());
			testVO.setTestDescription(testBO.getTestDescription());

			if (null!=testBO.getCommonsMultipartFile()&&!testBO.getCommonsMultipartFile().isEmpty()) {
				// If the image is changed means change their format.
				String img_contentType = testBO.getCommonsMultipartFile()
						.getContentType();
				String imageName = testVO.getImageName().split("\\.")[0]
						+ "." + img_contentType.split("/")[1];
				testVO.setImageName(imageName);
			}
			else{
				testVO.setImageName(testVO.getImageName());
			}
			TestBO testBoo = labDao.editTest(testVO);
			if (null == testBoo.getErrorCode()) {
				isStatus = true;
				if (null!=testBO.getCommonsMultipartFile()&&!testBO.getCommonsMultipartFile().isEmpty()) {
					String imagePath = HelloClinicResourceBundle
							.getValue("test.images.path");
					saveImages.saveImageToFolder(testVO.getImageName(),
							testBO.getCommonsMultipartFile(), imagePath);
				}
			}



		} catch (Exception he) {
			LOGGER.debug(he.getMessage() + he);
		}

		return isStatus;
	
	}

	@Override
	public TestBO deleteTest(TestBO testBO) {
		TestVO testVO = new TestVO();
		try {
			testVO.setTestId(testBO.getId());
			testVO.setIsDeleted(testBO.getIsDeleted());
			testVO.setModified(testBO.getModified());
			testVO.setModifiedBy(testBO.getModifiedBy());
			int result = labDao.deleteTest(testVO);
			if (result != 0) {
				testBO.setResponse(SuccessMsg.DELETE_SUCCESS);
			}
		} catch (Exception he) {
			//testBO.setErrorCode(he.getErrorCode());
			//testBO.setErrorMessage(he.getErrorMessage());
			LOGGER.debug(ErrorCodes.PT_LOG_FAIL + he);
		}

		return testBO;
	}

	@Override
	public List<TestTypeBO> retrieveTestTypeBO() {
		// TODO Auto-generated method stub
		return labDao.retrieveTestTypeBO();
	}

	@Override
	public List<TestBO> retriveTestName(TestBO testBO) {
		// TODO Auto-generated method stub
		return labDao.retriveTestName(testBO);
	}

	@Override
	public TestBO retriveTestAmount(TestBO testBO) {

		TestBO bo=new TestBO();
		TestVO VO= labDao.retriveTestAmount(testBO);
		if(null!=VO.getAmount())
		{
			bo.setAmount(VO.getAmount());		
		}
		return bo;		
	}

	@Override
	public boolean retriveTemplate(TemplateBO templateBO) {
		// TODO Auto-generated method stub	
		TemplateBO checktemplateBO=labDao.retriveTemplate(templateBO);	
		if(null!=checktemplateBO){
			return true;
		}
		return false;	
}

	@Override
	public boolean retriveTemplateCode(TemplateBO templateBO) {
		// TODO Auto-generated method stub
		TemplateBO checktemplateBO=labDao.retriveTemplateCode(templateBO);
		if(null!=checktemplateBO){
			return true;
		}
		return false;	
}

	@Override
	public Boolean createTemplate(TemplateBO templateBO) {
		boolean isStatus = false;
		
		TemplateVO templateVO = new TemplateVO();
		
		List<TemplateTestVO> templateTestlist= new ArrayList<TemplateTestVO>();
		
		for(TestBO testBO:templateBO.getTestList()){
			TemplateTestVO templateTest=new TemplateTestVO();
			TestVO testVO = new TestVO();
			testVO.setTestId(testBO.getId());
			templateTest.setTestvo(testVO);
			TestTypeVO testTypeVO=new TestTypeVO();
			testTypeVO.setTestTypeId(testBO.getTestTypeId());
			templateTest.setTestTypeVO(testTypeVO);
			templateTestlist.add(templateTest);
		}
		
		BeanUtils.copyProperties(templateBO, templateVO);
		templateVO.setTemplateTest(templateTestlist);
		long id = labDao.createTemplate(templateVO);
		if (0 != id) {
			isStatus = true;
		}

		return isStatus;
	}

	@Override
	public long imagelatestSequence(String columnName, String tableName) {
		// TODO Auto-generated method stub
		return labDao.findimageLatestSquence(columnName, tableName);
	}

}
