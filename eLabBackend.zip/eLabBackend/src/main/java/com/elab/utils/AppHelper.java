package com.elab.utils;

import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

import com.elab.model.BookAppointmentBO;
import com.paypal.api.payments.Amount;
import com.paypal.api.payments.Details;
import com.paypal.api.payments.Payer;
import com.paypal.api.payments.Payment;
import com.paypal.api.payments.RedirectUrls;
import com.paypal.api.payments.Transaction;
import com.paypal.core.rest.APIContext;
import com.paypal.core.rest.PayPalRESTException;

public class AppHelper {

	
	public static Payment createPayment(BookAppointmentBO bookAppointmentBO,
			String accessToken) throws FileNotFoundException,
			PayPalRESTException {

		Payment payment = new Payment();

		if (bookAppointmentBO.getPaymentMode().equalsIgnoreCase("paypal")) {
			Details amountDetails = new Details();
			amountDetails.setShipping(bookAppointmentBO.getShipping());
			amountDetails.setSubtotal(bookAppointmentBO.getAmount().toString());
			amountDetails.setTax(bookAppointmentBO.getTax());

			Amount amount = new Amount();
			amount.setCurrency(bookAppointmentBO.getCurrency());
			Double total = Double.parseDouble(bookAppointmentBO.getTax())
					+ Double.parseDouble(bookAppointmentBO.getShipping())
					+ Double.parseDouble(bookAppointmentBO.getAmount()
							.toString());
			amount.setTotal(String.format("%.2f", total));
			amount.setDetails(amountDetails);

			RedirectUrls redirectUrls = new RedirectUrls();
			redirectUrls.setCancelUrl(bookAppointmentBO.getCancelUrl());
			redirectUrls.setReturnUrl(bookAppointmentBO.getReturnUrl());

			Transaction transaction = new Transaction();
			transaction.setAmount(amount);
			List<Transaction> transactions = new ArrayList<Transaction>();
			transactions.add(transaction);

			Payer payer = new Payer();
			payer.setPaymentMethod(bookAppointmentBO.getPaymentMode());

			payment.setIntent(bookAppointmentBO.getPaymentIntent());
			payment.setPayer(payer);
			payment.setRedirectUrls(redirectUrls);
			payment.setTransactions(transactions);
		}

		// set access token

		Map<String, String> configurationMap = new HashMap<String, String>();
		configurationMap.put("oauth.EndPoint", HelloClinicResourceBundle
				.getValue("paypal.service.endPoint.url"));
		configurationMap.put("service.EndPoint", HelloClinicResourceBundle
				.getValue("paypal.service.endPoint.url"));
		configurationMap.put("mode",
				HelloClinicResourceBundle.getValue("paypal.service.mode"));
		String requestId = UUID.randomUUID().toString();
		APIContext apiContext = new APIContext(accessToken, requestId);
		apiContext.setConfigurationMap(configurationMap);
		return payment.create(apiContext);
	}
}
