package com.elab.utils;


import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

public class CommonFunction {

	public String getFileNameFromFilePath(String filePath) {
		String fileName = "";
		char[] stringArray;
		stringArray = filePath.toCharArray();
		String fileNameForSplit = "";
		for (int index = 0; index < stringArray.length; index++) {
			String tnn = filePath;
			if ((int) tnn.charAt(index) == 92) {
				fileNameForSplit += ":";
			} else {
				fileNameForSplit += stringArray[index];
			}
		}
		String splitArray[] = fileNameForSplit.split(":");
		fileName = splitArray[splitArray.length - 1];
		return fileName;
	}

	public String ConverToDBDate(String date) {
		if (date.equals(null) || date.equals("")) {
			return null;
		}
		String dbFormateDate = null;
		String dbFormateDateArray[] = null;
		if (date.contains("-")) {

			dbFormateDateArray = date.split("-");
		} else if (date.contains("/")) {
			dbFormateDateArray = date.split("/");
		}

		String dd = dbFormateDateArray[0];
		String mm = dbFormateDateArray[1];
		String yyyy = dbFormateDateArray[2];
		dbFormateDate = yyyy + "-" + mm + "-" + dd;
		return dbFormateDate;
	}

	public String ConverFromDBDate(String date) {
		if (date.equals(null) || date.equals("")) {
			return null;
		}
		String viewFormateDate = null;
		String dbFormateDateArray[] = null;
		dbFormateDateArray = date.split("-");
		String yyyy = dbFormateDateArray[0];
		String mm = dbFormateDateArray[1];
		String dd = dbFormateDateArray[2];
		viewFormateDate = dd + "-" + mm + "-" + yyyy;
		return viewFormateDate;
	}

	public Date ConverFromDbDate(String date) {
		if (date.equals(null) || date.equals("")) {
			return null;
		}
		String viewFormateDate = null;
		String dbFormateDateArray[] = null;
		dbFormateDateArray = date.split("-");
		String yyyy = dbFormateDateArray[0];
		String mm = dbFormateDateArray[1];
		String dd = dbFormateDateArray[2];
		viewFormateDate = dd + "-" + mm + "-" + yyyy;
		Date date1 = new Date(); // this method have to be change crctly...
		return date1;
	}

	public String ConverDatetoString(Date date) {
		if (date.equals(null) || date.equals("")) {
			return null;
		}
		String viewFormateDate = null;
		String dbFormateDateArray[] = null;
		// dbFormateDateArray = date.split("-"); // this method have to be
		// change crctly,,,
		String yyyy = dbFormateDateArray[0];
		String mm = dbFormateDateArray[1];
		String dd = dbFormateDateArray[2];
		viewFormateDate = dd + "-" + mm + "-" + yyyy;
		// Date date=viewFormateDate;
		return null;
	}

	public Date ConvertStringtoDate(String dateString) {
		if (dateString.equals(null) || dateString.equals("")) {
			return null;
		}
		SimpleDateFormat dateFormat = new SimpleDateFormat("dd-MM-yyyy");
		Date date = null;
		try {
			date = dateFormat.parse(dateString);
			String dateString2 = convertGMTtoddmmyyyy(date);
			date = dateFormat.parse(dateString2);
		} catch (Exception e) {
			// e.printStackTrace();
		}
		return date;
	}

	@SuppressWarnings("static-access")
	public String getWeekNumberFromDate(String date) {
		try {
			SimpleDateFormat sdf = new SimpleDateFormat();
			sdf.applyPattern("dd-MM-yyyy");
			Calendar calendar = Calendar.getInstance();
			Date processDate = sdf.parse(date);
			calendar.setTime(processDate);
			int week = calendar.get(calendar.WEEK_OF_YEAR);
			return String.valueOf(week);
		} catch (Exception e) {
			// TODO: handle exception
			// e.printStackTrace();
		}
		return null;
	}

	public String convertGMTtoddmmyyyy(String gmtDate) {
		String ddmmyyyy = null;
		if (gmtDate.equals(null) || gmtDate.equals("")) {
			return null;
		}
		String splitArray[] = gmtDate.split(" ");
		// Wed Feb 01 00:00:00 IST 2012
		String dd = splitArray[0];
		String mm = getMonthNumberFromMonthString(splitArray[1]);
		String yyyy = splitArray[3];
		int dateval = Integer.parseInt(dd);
		int monthval = Integer.parseInt(mm);
		if (dateval > 31 && monthval > 12) {
			return null;
		}
		ddmmyyyy = dd + "-" + mm + "-" + yyyy;
		return ddmmyyyy;
	}

	public String convertGMTtoddmmyyyy(Date gmtDate) {
		try {
			String ddmmyyyy = null;
			if (gmtDate.equals(null)) {
				return null;
			}
			String gmtStringDate = String.valueOf(gmtDate);
			String splitArray[] = gmtStringDate.split(" ");
			// Wed Feb 01 00:00:00 IST 2012
			String dd = splitArray[2];
			String mm = getMonthNumberFromMonthString(splitArray[1]);
			String yyyy = splitArray[5];
			ddmmyyyy = dd + "-" + mm + "-" + yyyy;

			return ddmmyyyy;
		} catch (Exception e) {
			// TODO: handle exception
			// e.printStackTrace();
		}
		return null;
	}

	public String convertGMTtodbDate(Date gmtDate) {
		try {
			String yyyymmdd = null;
			if (gmtDate.equals(null)) {
				return null;
			}
			String gmtStringDate = String.valueOf(gmtDate);
			String splitArray[] = gmtStringDate.split(" ");
			// Wed Feb 01 00:00:00 IST 2012
			String dd = splitArray[2];
			String mm = getMonthNumberFromMonthString(splitArray[1]);
			String yyyy = splitArray[5];
			yyyymmdd = yyyy + "-" + mm + "-" + dd;

			return yyyymmdd;
		} catch (Exception e) {
			// TODO: handle exception
			// e.printStackTrace();
		}
		return null;
	}

	public String getMonthNumberFromMonthString(String monthString) {
		String monthNumber = null;
		if (monthString.equals("Jan")) {
			monthNumber = "01";
		} else if (monthString.equals("Feb")) {
			monthNumber = "02";
		} else if (monthString.equals("Mar")) {
			monthNumber = "03";
		} else if (monthString.equals("Apr")) {
			monthNumber = "04";
		} else if (monthString.equals("May")) {
			monthNumber = "05";
		} else if (monthString.equals("Jun")) {
			monthNumber = "06";
		} else if (monthString.equals("Jul")) {
			monthNumber = "07";
		} else if (monthString.equals("Aug")) {
			monthNumber = "08";
		} else if (monthString.equals("Sep")) {
			monthNumber = "09";
		} else if (monthString.equals("Oct")) {
			monthNumber = "10";
		} else if (monthString.equals("Nov")) {
			monthNumber = "11";
		} else if (monthString.equals("Dec")) {
			monthNumber = "12";
		}
		return monthNumber;
	}

	public String getLastMMM_yyyy(String currentMMM_yyyy) {
		String lastMMM_yyyy = null;
		String splitArray[] = currentMMM_yyyy.split(" ");
		String currentMonth = splitArray[0];
		int currentYear = Integer.parseInt(splitArray[1]);
		if (currentMonth.equalsIgnoreCase("Jan")) {
			currentYear = currentYear - 1;
			lastMMM_yyyy = "Dec " + currentYear;
		}
		if (currentMonth.equalsIgnoreCase("Feb")) {
			lastMMM_yyyy = "Jan " + currentYear;
		}
		if (currentMonth.equalsIgnoreCase("Mar")) {
			lastMMM_yyyy = "Feb " + currentYear;
		}
		if (currentMonth.equalsIgnoreCase("Apr")) {
			lastMMM_yyyy = "Mar " + currentYear;
		}
		if (currentMonth.equalsIgnoreCase("May")) {
			lastMMM_yyyy = "Apr " + currentYear;
		}
		if (currentMonth.equalsIgnoreCase("Jun")) {
			lastMMM_yyyy = "May " + currentYear;
		}
		if (currentMonth.equalsIgnoreCase("Jul")) {
			lastMMM_yyyy = "Jun " + currentYear;
		}
		if (currentMonth.equalsIgnoreCase("Aug")) {
			lastMMM_yyyy = "Jul " + currentYear;
		}
		if (currentMonth.equalsIgnoreCase("Sep")) {
			lastMMM_yyyy = "Aug " + currentYear;
		}
		if (currentMonth.equalsIgnoreCase("Oct")) {
			lastMMM_yyyy = "Sep " + currentYear;
		}
		if (currentMonth.equalsIgnoreCase("Nov")) {
			lastMMM_yyyy = "Oct " + currentYear;
		}
		if (currentMonth.equalsIgnoreCase("Dec")) {
			lastMMM_yyyy = "Nov " + currentYear;
		}
		return lastMMM_yyyy;
	}

	public Date removeTimestampFromDate(Date date) throws ParseException {
		SimpleDateFormat formatter = new SimpleDateFormat("dd/MM/yyyy");
		String todayDate = formatter.format(date);
		Date formattedDate = null;
		formattedDate = formatter.parse(todayDate);
		return formattedDate;
	}

	public static void main(String[] args) {
		Date date = new Date();
		SimpleDateFormat formatter = new SimpleDateFormat("dd/MM/yyyy");
		String todayDate = formatter.format(date);
		
		
		Calendar cal = Calendar.getInstance();
		cal.setTime(date);
		 
		// Set time fields to zero
		cal.set(Calendar.HOUR_OF_DAY, 0);
		cal.set(Calendar.MINUTE, 0);
		cal.set(Calendar.SECOND, 0);
		cal.set(Calendar.MILLISECOND, 0);
		 
		// Put it back in the Date object
		date = cal.getTime();
		
		
	}

}
