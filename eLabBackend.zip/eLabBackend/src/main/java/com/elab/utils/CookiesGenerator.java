/**
 * 
 */
package com.elab.utils;

import java.util.Map;

import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.elab.model.AdminLoginBO;
import com.elab.model.LoginBO;

public class CookiesGenerator {

	public void addCookies(HttpServletRequest request,
			HttpServletResponse response, Map<String, String> cookiesObject,
			String type, boolean rememberMe) {

		if (type.equalsIgnoreCase("patient")) {
			if (rememberMe) {
				Cookie j_EmailCookie = new Cookie("j_cookieEmail",
						cookiesObject.get("email"));
				Cookie j_PasswordCookie = new Cookie("j_cookiePass",
						cookiesObject.get("password"));
				/*Cookie j_mobileCookie = new Cookie("j_cookiemobile",
						cookiesObject.get("mobileNo"));*/
				/*Cookie j_patientCookie = new Cookie("j_cookiePass",
						cookiesObject.get("patient"));*/
				Cookie j_RememerCookie = new Cookie("j_cookieRemember", "1");
				j_EmailCookie.setMaxAge(60 * 60 * 24 * 15);// 15 days
				j_PasswordCookie.setMaxAge(60 * 60 * 24 * 15);
				/*j_mobileCookie.setMaxAge(60 * 60 * 24 * 15);*/
				j_RememerCookie.setMaxAge(60 * 60 * 24 * 15);
				response.addCookie(j_EmailCookie);
				response.addCookie(j_PasswordCookie);
				response.addCookie(j_RememerCookie);
				/*response.addCookie(j_patientCookie);*/
				/*response.addCookie(j_mobileCookie);*/
			} else {
				Cookie j_EmailCookie = new Cookie("j_cookieEmail", null);
				Cookie j_PasswordCookie = new Cookie("j_cookiePass", null);
				Cookie j_RememerCookie = new Cookie("j_cookieRemember", null);
				j_EmailCookie.setMaxAge(0);
				j_PasswordCookie.setMaxAge(0);
				j_RememerCookie.setMaxAge(0);
				response.addCookie(j_EmailCookie);
				response.addCookie(j_PasswordCookie);
				response.addCookie(j_RememerCookie);
			}
		}
		if (type.equalsIgnoreCase("admin")) {
			if (rememberMe) {
				Cookie j_EmailCookie = new Cookie("j_cookieEmail",
						cookiesObject.get("email"));
				Cookie j_PasswordCookie = new Cookie("j_cookiePass",
						cookiesObject.get("password"));
				/*Cookie j_adminCookie = new Cookie("j_cookiePass",
						cookiesObject.get("admin"));*/
				/*Cookie j_mobileCookie = new Cookie("j_cookiemobile",
						cookiesObject.get("mobileNo"));*/
				Cookie j_RememerCookie = new Cookie("j_cookieRemember", "1");
				j_EmailCookie.setMaxAge(60 * 60 * 24 * 15);// 15 days
				j_PasswordCookie.setMaxAge(60 * 60 * 24 * 15);
				/*j_mobileCookie.setMaxAge(60 * 60 * 24 * 15);*/
				j_RememerCookie.setMaxAge(60 * 60 * 24 * 15);
				response.addCookie(j_EmailCookie);
				response.addCookie(j_PasswordCookie);
				response.addCookie(j_RememerCookie);
				/*response.addCookie(j_adminCookie);*/
				/*response.addCookie(j_mobileCookie);*/
			} else {
				Cookie j_EmailCookie = new Cookie("j_cookieEmail", null);
				Cookie j_PasswordCookie = new Cookie("j_cookiePass", null);
				Cookie j_RememerCookie = new Cookie("j_cookieRemember", null);
				j_EmailCookie.setMaxAge(0);
				j_PasswordCookie.setMaxAge(0);
				j_RememerCookie.setMaxAge(0);
				response.addCookie(j_EmailCookie);
				response.addCookie(j_PasswordCookie);
				response.addCookie(j_RememerCookie);
			}
		}
	}

	public Object cookiesVerifications(HttpServletRequest request,
			Object formObject, String type) {

		Cookie[] cookies = request.getCookies();
		if (cookies != null) {
			if (type.equalsIgnoreCase("patient")) {
				LoginBO patientBO = (LoginBO) formObject;
				for (Cookie cookie : cookies) {
					if (cookie.getName().equals("j_cookieEmail")) {
						patientBO.setEmailAddress(cookie.getValue());
					}
					if (cookie.getName().equals("j_cookiePass")) {
						patientBO.setPassword(cookie.getValue());
					}
					/*if (cookie.getName().equals("j_cookiemobile")) {
						patientBO.setMobileNo(Long.parseLong(cookie
								.getValue().toString()));
					}*/
					if (cookie.getName().equals("j_cookieRemember")) {
						patientBO.setRememberMe(true);
					}
				}
				return patientBO;
			}
		}
		if (cookies != null) {
			if (type.equalsIgnoreCase("admin")) {
				AdminLoginBO adminLoginBO = (AdminLoginBO) formObject;
				for (Cookie cookie : cookies) {
					if (cookie.getName().equals("j_cookieEmail")) {
						adminLoginBO.setEmailAddress(cookie.getValue());
					}
					if (cookie.getName().equals("j_cookiePass")) {
						adminLoginBO.setPassword(cookie.getValue());
					}
					/*if (cookie.getName().equals("j_cookiemobile")) {
						patientBO.setMobileNo(Long.parseLong(cookie
								.getValue().toString()));
					}*/
					if (cookie.getName().equals("j_cookieRemember")) {
						adminLoginBO.setRememberMe(true);
					}
				}
				return adminLoginBO;
			}
		}
		return formObject;
	}
}
