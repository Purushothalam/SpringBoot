package com.elab.utils;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import org.springframework.ui.Model;

public class DropdownUtils {
	
	static String qulalificationList;
	static List<String> qualifications=new ArrayList<String>();

	public void doctorQualification(Model model) {
		try {
			String str=HelloClinicResourceBundle.getValue("test_qualification");
		} catch (Exception e) {

		}
	}

	public static List<String> getQualifications(){
		try{
		String str= HelloClinicResourceBundle.getValue("doctors.qualification");
	    qualifications = Arrays.asList(str.split(","));
		}
		catch(Exception e){
			
		}
		return qualifications;
	}

}
