package com.elab.utils;

public class EmailCodes {
	
	public static final String PASSWORD_CHANGE="passwordChange";
	
	public static final String BOOK_APPOINTMENT="bookappointment";
	
	public static final String CONSULT_REQUEST="ConsultationRequest";
	
	public static final String PATIENT_REQUEST="patientConsultSuccess";
	
	public static final String DONOR_APPROVAL="DonorApproval";
	
	public static final String DONOR_REQUEST="DonorRequest";
	
	public static final String CONSULT_ATTACHMENT="ConsultWithAttachment";
	
	public static final String ACCOUNT_ACTIVATION_SUCCESS="AccountActivation";
	
	
	public static final String GET_PRESCREPTION="GetPrescription";

	public static String APPOINTMENT_BY_OWN="appointmentbyown";
	
	public static String APPOINTMENT_BY_ADMIN="appointmentbyadmin";
	
	public static String REPORT_UPLOAD="reportUpload";
	
	
	

}
