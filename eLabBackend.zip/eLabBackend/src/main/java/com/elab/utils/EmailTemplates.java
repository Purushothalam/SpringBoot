/**
 * 
 */
package com.elab.utils;

import java.io.FileNotFoundException;

/**
 * @author Administrator
 *
 */
public class EmailTemplates {
	
	
	public static String activationTemaplate(String name,String emailId) throws FileNotFoundException{
		
		String str=HelloClinicResourceBundle.getValue("PatientLogin");
		
		String bodyContent = "Dear "+name+","
				+ "\n\n\tClick here to conformation your registration in Helloclinic:\n"
				+ str
				+ emailId
				+ "\n"
				+ "\n\n\n\n\nRegards,\n Customer Support,\n HelloClinic Customer Services.";
		return bodyContent;
	}
	
	
	
	
	


}
