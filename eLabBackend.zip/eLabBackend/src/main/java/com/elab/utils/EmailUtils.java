package com.elab.utils;

import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;
import java.io.OutputStream;

import javax.activation.MimetypesFileTypeMap;



import org.apache.log4j.Logger;
import org.springframework.web.multipart.commons.CommonsMultipartFile;



public class EmailUtils {/*

	private static final Logger LOGGER = Logger
			.getLogger(EmailUtils.class);
	public static CommonsMultipartFile getCommonsMultipartFiles(String fileName) throws Exception{	
		LOGGER.info("Trying to stream the file to attach in the email:"+fileName);
		File file = new File(fileName);	  
		FileItem fi = createFileItem( "file", file );
		CommonsMultipartFile f = new CommonsMultipartFile(fi);
		return f;	 
	}

	private static FileItem createFileItem( String fieldName, File file ) throws Exception{	  
		boolean isFormField = false;
		String fileName = file.getName();
		String contentType = new MimetypesFileTypeMap().getContentType( file );	  
		DiskFileItemFactory factory = new DiskFileItemFactory();
		FileItem fi = factory.createItem( fieldName, contentType, isFormField, fileName );	  
		InputStream input =  new FileInputStream( file );
		OutputStream output = fi.getOutputStream();	        
		IOUtils.copy( input, output );	        
		IOUtils.closeQuietly( input );
		IOUtils.closeQuietly( output );	        
		return fi;
	}


*/}
