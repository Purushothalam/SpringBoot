package com.elab.utils;

public class ErrorCodes {

	
	
	
	
	// Patient Registration Creation Failed ErrorCode..
	public static final String PT_REG_FAIL = "PT0001";
	// Patient Registration Creation Failed ErrorMessage..
	public static final String PT_REG_FAIL_MSG = "Patient Registration Failed";

		
	// Patient Login failed ErrorCode
		public static final String PT_LOG_FAIL = "PT0002";
		//  Patient Login failed ErrorMessage
		public static final String PT_LOG_FAIL_MSG = "Patient Login Failed";		
				
				
		// Patient find email fun failed ErrorCode
				public static final String PT_FIN_FAIL = "PT0003";
				//  Patient find email fun failed ErrorMessage
				public static final String PT_FIN_FAIL_MSG = "Patient Find Email Function Failed";	
				
				
				
				// Patient find email fun failed ErrorCode
						public static final String PT_UP_FAIL = "PT0004";
						//  Patient find email fun failed ErrorMessage
						public static final String PT_UP_FAIL_MSG = "Data Update Failed";	
						
						
						// Patient find email fun failed ErrorCode
						public static final String AD_DATA_FAIL = "PT0005";
						//  Patient find email fun failed ErrorMessage
						public static final String AD_DATA_FAIL_MSG = "Data Added Failed";	
		
						// Patient Registration Creation Failed ErrorCode..
						public static final String PT_RE_FAIL = "PT0006";
						// Patient Registration Creation Failed ErrorMessage..
						public static final String PT_RE_FAIL_MSG = "Data Reterive Failed";
						public static final String Email_FAIL = "HE0001";
						public static final String Email_FAIL_MSG = "Email Attachement Failed";
}
