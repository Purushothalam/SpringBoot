package com.elab.utils;

import com.itextpdf.text.Rectangle;
import com.itextpdf.text.pdf.PdfContentByte;
import com.itextpdf.text.pdf.PdfPCell;
import com.itextpdf.text.pdf.PdfPCellEvent;
import com.itextpdf.text.pdf.PdfPTable;

public class GeneratePDF {

	class SpecialRoundedCell implements PdfPCellEvent {
        @Override
		public void cellLayout(PdfPCell cell, Rectangle position,
				PdfContentByte[] canvases) {
			PdfContentByte canvas = canvases[PdfPTable.LINECANVAS];
            float llx = position.getLeft() + 2;
            float lly = position.getBottom() + 2;
            float urx = position.getRight() - 2;
            float ury = position.getTop() - 2;
            float r = 4;
            float b = 0.4477f;
            canvas.moveTo(llx, lly);
            canvas.lineTo(urx, lly);
            canvas.lineTo(urx, ury - r);
            canvas.curveTo(urx, ury - r * b, urx - r * b, ury, urx - r, ury);
            canvas.lineTo(llx + r, ury);
            canvas.curveTo(llx + r * b, ury, llx, ury - r * b, llx, ury - r);
            canvas.lineTo(llx, lly);
            canvas.stroke();			
		}
    }
	
	 public PdfPCell getCell(PdfPTable pTable) {
	        PdfPCell cell = new PdfPCell(pTable);
	        cell.setCellEvent(new SpecialRoundedCell());
	        cell.setPadding(5);
	        cell.setBorder(PdfPCell.NO_BORDER);
	        return cell;
	    }
}
