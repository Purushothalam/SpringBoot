package com.elab.utils;

import java.util.ArrayList;
import java.util.List;

import com.elab.model.PaginationBO;




/**
 * @author User
 * 
 */
public class PaginationClass {

	
	public static List<PaginationBO> paginationLimitedRecords(long page,
			 long records, long totalRecordCount) {

		long recordsPerPage = records;
		long noOfRecords = (long) totalRecordCount;
		long pageLinkLimit = 1;
		List<PaginationBO> noOfPages = new ArrayList<PaginationBO>();
		PaginationBO pages;
		//PaginationBO<Object> ro = new PaginationBO<Object>();
		//ro.setListSize(totalRecordCount);
		//ro.setCurrentPage(page);
		long tempPages = (long) Math.ceil(noOfRecords * 1.0 / recordsPerPage);
		for (long i = (page > 7 ? (page < (tempPages - 8) ? (page - 5)
				: ((page - 9) <= 0 ? 1 : (tempPages - 9))) : 1); i <= tempPages; i++) {
			pages=new PaginationBO();
			pages.setNoOfPages(i);
			pages.setCurrentPage(page);
			pages.setListSize(totalRecordCount);
			pages.setTotalPages(tempPages);
			pages.setLastRecordValue(tempPages);
			noOfPages.add(pages);
			pageLinkLimit++;
			if (pageLinkLimit > 10) {
				break;
			}
		}
		/*ro.setNoOfPages(noOfPages);
		ro.setTotalPages(tempPages);
		ro.setLastRecordValue((tempPages));
		List<Object> list = (List<Object>) dataLsit;
		ro.setList(list);*/

		return noOfPages;
	}
	public static int paginationPageValues(int pageid, int recordPerPage) {
		int pageRecords = 0;
		if (pageid == 1) {
			pageRecords = 0;
		} else {
			pageRecords = (pageid - 1) * recordPerPage + 1;
			pageRecords = pageRecords - 1;
		}
		return pageRecords;
	}
}
