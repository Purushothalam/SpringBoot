package com.elab.utils;

import java.io.File;
import java.io.IOException;

import org.apache.commons.io.FileUtils;
import org.apache.log4j.Logger;
import org.springframework.web.multipart.MultipartFile;

public class SaveImagesToFolder {

	private static final Logger LOGGER = Logger.getLogger(SaveImagesToFolder.class);

	public void saveImageToFolder(String filename, MultipartFile image, String filePath)
			throws RuntimeException, IOException {
		try {
			File file = new File(filePath + filename);
			//Delete the file if it is exist 
						
			if(file.exists()){
				try{
				file.delete();
				}catch(Exception ie){
					LOGGER.debug("Existing Image delete had probelm:" + ie.getMessage());			}
			}
			
			FileUtils.writeByteArrayToFile(file, image.getBytes());			
		} catch (Exception ex) {
			ex.printStackTrace();
			if (LOGGER.isDebugEnabled()) {
				LOGGER.debug("Image upload to folder has failed:" + ex.getMessage());
			}
			LOGGER.info("Image upload to folder has failed:" + ex.getMessage());
		}
	}

}
