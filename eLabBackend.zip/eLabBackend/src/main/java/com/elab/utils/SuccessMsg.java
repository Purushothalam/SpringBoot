package com.elab.utils;

public class SuccessMsg {

	public static final String PT_REG_SUCCESS = "Patient Registered Successfully.";

	public static final String PT_ACC_ACTIVATION = " Account has been Successfully Activated.";
	
	public static final String AD_UP = "Data has been updated successfully.";
	
	public static final String DELETE_SUCCESS = "Data has been Deleted successfully.";
	
	public static final String AD_SU = "Data has been Added successfully.";

	
	
}
