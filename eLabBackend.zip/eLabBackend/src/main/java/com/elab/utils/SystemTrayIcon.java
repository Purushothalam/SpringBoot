package com.elab.utils;

import java.awt.*;
import java.awt.TrayIcon.MessageType;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.util.Date;
import java.util.Map;

import javax.swing.ImageIcon;

import org.hibernate.Criteria;

public class SystemTrayIcon{
	
	
	    public static  void displayTray(String date) throws AWTException{
	        //Obtain only one instance of the SystemTray object
	        SystemTray tray = SystemTray.getSystemTray();
	        //Creating a tray icon
	        Image image = Toolkit.getDefaultToolkit().createImage("icon.png");
	       
	      
	        //System.out.println(image);
	        TrayIcon trayIcon = new TrayIcon(image, "Tray Demo");
	        //Let the system resizes the image if needed
	        trayIcon.setImageAutoSize(true);
	        //Set tooltip text for the tray icon
	        trayIcon.setToolTip("System tray icon demo");
	        tray.add(trayIcon);
	         trayIcon.displayMessage("eLab", "You have our appointment on : "+date, MessageType.INFO);
	         
	         
	    }
	         
	    
	    public static void displayTrayPending(Map<String, String> count) throws AWTException
	    {
	    	
		        //Obtain only one instance of the SystemTray object
		        SystemTray tray = SystemTray.getSystemTray();
		        //Creating a tray icon
		        Image image = Toolkit.getDefaultToolkit().createImage("icon.png");
		       
		      
		        //System.out.println(image);
		        TrayIcon trayIcon = new TrayIcon(image, "Tray Demo");
		        //Let the system resizes the image if needed
		        trayIcon.setImageAutoSize(true);
		        //Set tooltip text for the tray icon
		        trayIcon.setToolTip("System tray icon demo");
		        tray.add(trayIcon);
		         trayIcon.displayMessage("eLab", "You have "+count+ "Pending Requests", MessageType.INFO);
		         
	    }


		

		
	        
	         
	    



}
